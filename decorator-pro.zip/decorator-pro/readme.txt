/*-----------------------------------------------------------------------------------*/
/* Decorator WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   Decorator
Theme URI       :   https://flythemes.net/wordpress-themes/decorator-wordpress-theme/
Version         :   Pro 1.0
Tested up to    :   WP 4.7
Author          :   Fly Themes
Author URI      :   https://www.flythemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@flythemes.net

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- Nivoslider is licensed under MIT License.
- html5.js is dual licensed under MIT and GPL2.

2 - 	Fonts used in this theme are defined below

	Montserrat :https://www.google.com/fonts/specimen/Montserrat
	Karla	   :https://www.google.com/fonts/specimen/Karla
	License: Distributed under the terms of the Apache License, version 2.0 		
	http://www.apache.org/licenses/LICENSE-2.0.html

3 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 
	(https://creativecommons.org/about/cc0)	

	Slider:
	------
	https://pixabay.com/en/governor-s-mansion-montgomery-1612734/		

	Pages:
	-----------
	https://pixabay.com/en/bedroom-bed-bedside-lamp-490779/
	https://pixabay.com/en/tap-black-faucet-kitchen-sink-791172/
	https://pixabay.com/en/family-room-living-room-sofa-chairs-670270/

	Get A Quote
	-----------
	https://pixabay.com/en/staircase-window-view-architecture-1149510/

	Recent Work
	------------
	https://pixabay.com/en/table-coffee-table-white-industial-791584/
	https://pixabay.com/en/living-room-real-estate-residential-527646/
	https://pixabay.com/en/corridor-passageway-hall-670277/
	https://pixabay.com/en/family-room-living-room-sofa-chairs-670270/
	https://pixabay.com/en/illumination-lights-bulbs-731494/
	https://pixabay.com/en/bedroom-bed-bedside-lamp-490779/
	https://pixabay.com/en/decor-interior-design-couch-tables-699175/
	https://pixabay.com/en/interior-design-home-house-design-413718/
	https://pixabay.com/en/tap-black-faucet-kitchen-sink-791172/

	Inner Banner
	------------
	https://pixabay.com/en/abstract-antique-backdrop-1866665/

	Portfolio
	----------

	Washroom
	---------
	https://pixabay.com/en/hotel-bathroom-interior-villa-1737171/
	https://pixabay.com/en/bathroom-shower-tub-room-interior-881124/
	https://pixabay.com/en/bathroom-bad-toilet-bathroom-sink-1228427/

	Living room
	-----------
	https://pixabay.com/en/lobby-reception-hall-hotel-346426/
	https://pixabay.com/en/governor-s-mansion-montgomery-1612734/
	https://pixabay.com/en/livingroom-living-room-furniture-275841/

	Bedroom
	-------

	https://pixabay.com/en/bedroom-real-estate-interior-design-1940169/
	https://pixabay.com/en/bedroom-bed-bedside-lamp-490779/
	https://pixabay.com/en/bedroom-hotel-interior-1737167/

	Kitchen
	-------

	https://pixabay.com/en/tap-black-faucet-kitchen-sink-791172/
	https://pixabay.com/en/ginsburgconstruction-kitchen-3-330737/
	https://pixabay.com/en/kitchen-interior-stove-cooking-1756631/
	

For any help you can mail us at support[at]flythemes.net