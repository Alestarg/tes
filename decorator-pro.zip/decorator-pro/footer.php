<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Decorator Pro
 */
?>

<div id="footer-contact">
          <div class="footer-inner">
            <div class="contact-cols">
               <?php if( of_get_option('address',true) != ''){ ?>
               <div class="foot-icon"><i class="fa fa-map-marker"></i></div><h4><?php echo of_get_option('address'); ?></h4>
               <?php } ?>
            </div><!-- contact-cols -->
                
            <div class="contact-cols">
               <?php if( of_get_option('phone',true) != ''){ ?>
               <div class="foot-icon"><i class="fa fa-phone"></i></div><h4><?php echo of_get_option('phone'); ?></h4>
               <?php } ?>
            </div><!-- contact-cols -->
                
            <div class="contact-cols last">
              <?php if( of_get_option('email',true) != '' ) { ?>
              <div class="foot-icon"><i class="fa fa-envelope"></i></div><h4><a href="mailto:<?php echo of_get_option('email',true); ?>"><?php echo of_get_option('email',true) ; ?></a></h4>
              <?php } ?>
            </div><!-- contact-cols -->
            <div class="clear"></div>
          </div><!-- footer-inner -->
</div><!-- footer-contact -->

<div id="footer-wrapper">   
        
    	<div class="container">        	
        	<?php if(!dynamic_sidebar('footer-1')) : ?>
              <div class="cols-3 widget-column-1"> 
              	<h5><?php if( of_get_option('abouttitle') != '') { echo of_get_option('abouttitle'); } ; ?></h5>
                <?php if( of_get_option('aboutusdescription') != '') { echo of_get_option('aboutusdescription'); } ; ?>
                
                <?php if( of_get_option('footersocialicon') != '') { echo do_shortcode(of_get_option('footersocialicon')); } ; ?>
               </div>
            <?php endif; ?>           
            
          
           <?php if(!dynamic_sidebar('footer-2')) : ?>
              <div class="cols-3 widget-column-2">                           	
               <h5><?php if( of_get_option('letestpoststitle') != ''){ echo of_get_option('letestpoststitle');}; ?></h5>
                <ul class="recent-post"> 
                	<?php query_posts('post_type=post&showposts=3'); ?>
                    <?php  while( have_posts() ) : the_post(); ?>
                  	
                    <li>
                    <strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong>                   
                    <?php echo content( of_get_option('footerpostslength') ); ?>					
                    </li>
                    <?php endwhile; ?>
                    </ul>
                    <?php wp_reset_query(); ?>
               </div>
            <?php endif; ?>
            
            
            <?php if(!dynamic_sidebar('footer-3')) : ?> 
             <div class="cols-3 widget-column-3">  
             	<h5><?php if( of_get_option('recenttitle') != ''){ echo of_get_option('recenttitle');}; ?></h5>
               		<ul class="foot-recent"> 
                	<?php query_posts('post_type=recent_work&showposts=9'); ?>
                    <?php  while( have_posts() ) : the_post(); ?>                  	
                    <li>
                    <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) { $src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail' );   $thumbnailSrc = $src[0]; ?>
                    <div class="footerthumb"><img src="<?php echo $thumbnailSrc; ?>" alt="" width="70" height="auto" ></div><?php } 
                    else { ?>
                    <img src="<?php echo esc_url( get_template_directory_uri()); ?>/images/img_404.png" width="70"  />
                    <?php } ?></a> 
                    				
                    </li>
                    <?php endwhile; ?><div class="clear"></div>
                    </ul>
                    <?php wp_reset_query(); ?>  
              </div>             
            <?php endif; ?>             
            
            <div class="clear"></div>
        </div><!--end .container-->
     
        <div class="copyright-wrapper">
        	<div class="container">
            	<div class="copyright-inner">
                    <div class="copyright-txt"><?php if( of_get_option('copytext',true) != ''){ echo of_get_option('copytext',true); }; ?></div>
                    <div class="designby"><?php if( of_get_option('designbytext',true) != ''){ echo of_get_option('designbytext',true); }; ?></div>
                    <div class="clear"></div>
                </div><!-- copyright-inner -->
            </div> 
       </div>
       
    </div>    
<?php if( of_get_option('backtotop') != '') { echo do_shortcode(of_get_option('backtotop')); } ; ?>
<?php wp_footer(); ?>
</div>
</body>
</html>