<?php
/**
 * Decorator functions and definitions
 *
 * @package Decorator Pro
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
function content($limit) {
$content = explode(' ', get_the_excerpt(), $limit);
if (count($content)>=$limit) {
array_pop($content);
$content = implode(" ",$content).'...';
} else {
$content = implode(" ",$content);
}	
$content = preg_replace('/\[.+\]/','', $content);
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
return $content;
}
//Excerpt limit function
function custom_excerpt_length( $length ) {
	return 100;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

if ( ! function_exists( 'decorator_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function decorator_setup() {

	if ( ! isset( $content_width ) )
		$content_width = 640; /* pixels */

	load_theme_textdomain( 'decorator', get_template_directory() . '/languages' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'title-tag' );
	add_image_size('homepage-thumb',240,145,true);	
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'decorator' ),
		'footer' => __( 'Footer Menu', 'decorator' ),		
	) );
	add_theme_support( 'custom-background', array(
		'default-color' => 'ffffff'
	) );
	add_editor_style( 'editor-style.css' );
}
endif; // decorator_setup
add_action( 'after_setup_theme', 'decorator_setup' );

function decorator_widgets_init() {

	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'decorator' ),
		'description'   => __( 'Appears on blog page sidebar', 'decorator' ),
		'id'            => 'sidebar-1',
		'before_widget' => '',		
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3><aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '<div class="clear"></div></aside>',
	) );

	register_sidebar( array(
		'name'          => __( 'Sidebar Main', 'decorator' ),
		'description'   => __( 'Appears on page sidebar', 'decorator' ),
		'id'            => 'sidebar-main',
		'before_widget' => '',		
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3><aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
	) );	
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 1', 'decorator' ),
		'description'   => __( 'Appears on footer', 'decorator' ),
		'id'            => 'footer-1',
		'before_widget' => '<div id="%1$s" class="cols-3 widget-column-1">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5>',
		'after_title'   => '</h5>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 2', 'decorator' ),
		'description'   => __( 'Appears on footer', 'decorator' ),
		'id'            => 'footer-2',
		'before_widget' => '<div id="%1$s" class="cols-3 widget-column-2">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5>',
		'after_title'   => '</h5>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 3', 'decorator' ),
		'description'   => __( 'Appears on footer', 'decorator' ),
		'id'            => 'footer-3',
		'before_widget' => '<div id="%1$s" class="cols-3 widget-column-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<h5>',
		'after_title'   => '</h5>',
	) );
	
	
	register_sidebar( array(
		'name'          => __( 'Sidebar Contact Page', 'decorator' ),
		'description'   => __( 'Appears on contact page', 'decorator' ),
		'id'            => 'sidebar-contact',
		'before_widget' => '<aside class="widget-contact %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Header Widget', 'decorator' ),
		'description'   => __( 'Appears on top of the header', 'decorator' ),
		'id'            => 'header-widget',
		'before_widget' => '<div class="headerinfo">',
		'after_widget'  => '</div>',
		'before_title'  => '<h6 style="display:none">',
		'after_title'   => '</h6>',
	) );
		

}
add_action( 'widgets_init', 'decorator_widgets_init' );

define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once get_template_directory() . '/inc/options-framework.php';

function decorator_scripts() {	
	wp_enqueue_style( 'decorator-gfonts-Montserrat', '//fonts.googleapis.com/css?family=Montserrat:400,700' );
	wp_enqueue_style( 'decorator-gfonts-Karla', '//fonts.googleapis.com/css?family=Karla:400,700' );	

	if( of_get_option('bodyfontface',true) != '' ){
		wp_enqueue_style( 'decorator-gfonts-body', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('bodyfontface',true)) .'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if( of_get_option('logofontface',true) != '' ){
		wp_enqueue_style( 'decorator-gfonts-logo', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('logofontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('navfontface', true) != '' ) {
		wp_enqueue_style( 'decorator-gfonts-nav', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('navfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('headfontface', true) != '' ) {
		wp_enqueue_style( 'decorator-gfonts-heading', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('headfontface',true)) .'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin');
	}
 	if ( of_get_option('oswaldfontface', true) != '' ) {
		wp_enqueue_style( 'decorator-gfonts-teamserv', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('oswaldfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}

	wp_enqueue_style( 'decorator-basic-style', get_stylesheet_uri() );
	wp_enqueue_style( 'decorator-editor-style', get_template_directory_uri().'/editor-style.css' );
	wp_enqueue_style( 'decorator-base-style', get_template_directory_uri().'/css/default.css' );	
	if ( is_home() || is_front_page() ) { 
	wp_enqueue_style( 'decorator-nivo-style', get_template_directory_uri().'/css/nivo-slider.css' );
	wp_enqueue_script( 'decorator-nivo-slider', get_template_directory_uri() . '/js/jquery.nivo.slider.js', array('jquery') );
	}	

	wp_enqueue_script( 'decorator-customscripts', get_template_directory_uri() . '/js/custom.js', array('jquery') );	
	wp_enqueue_style( 'decorator-font-awesome-style', get_template_directory_uri().'/css/font-awesome.css' );	
	wp_enqueue_script( 'decorator-testimonialsminjs', get_template_directory_uri().'/testimonialsrotator/js/jquery.quovolver.min.js', array('jquery') );
	wp_enqueue_script( 'decorator-testimonials-bootstrap', get_template_directory_uri().'/testimonialsrotator/js/bootstrap.js', array('jquery') );
	wp_enqueue_style( 'decorator-testimonialslider-style', get_template_directory_uri().'/testimonialsrotator/js/tm-rotator.css' );	
	wp_enqueue_style( 'decorator-responsive-style', get_template_directory_uri().'/css/responsive.css' );		
	wp_enqueue_style( 'decorator-owl-style', get_template_directory_uri().'/testimonialsrotator/js/owl.carousel.css' );
	wp_enqueue_script( 'decorator-owljs', get_template_directory_uri().'/testimonialsrotator/js/owl.carousel.js', array('jquery') );	
	
	// mixitup script
	wp_enqueue_style( 'decorator-mixitup-style', get_template_directory_uri().'/mixitup/style-mixitup.css' );
	wp_enqueue_script( 'decorator-jquery_013-script', get_template_directory_uri() . '/mixitup/jquery_013.js', array('jquery') );
	wp_enqueue_script( 'decorator-jquery_003-script', get_template_directory_uri() . '/mixitup/jquery_003.js', array('jquery') );
	wp_enqueue_script( 'decorator-screen-script', get_template_directory_uri() . '/mixitup/screen.js', array('jquery') );
	// prettyPhoto script
	wp_enqueue_style( 'decorator-prettyphoto-style', get_template_directory_uri().'/mixitup/prettyPhotoe735.css' );
	wp_enqueue_script( 'decorator-prettyphoto-script', get_template_directory_uri() . '/mixitup/jquery.prettyPhoto5152.js', array('jquery') );
	
	//Client Logo Rotator
	wp_enqueue_style( 'decorator-flexiselcss', get_template_directory_uri().'/css/flexiselcss.css' );	
	wp_enqueue_script( 'decorator-flexisel', get_template_directory_uri() . '/js/jquery.flexisel.js', array('jquery') );
	
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'decorator_scripts' );

function media_css_hook(){
	
	?>
    	
    	<script>			
		jQuery(window).load(function() {
        jQuery('#slider').nivoSlider({
        	effect:'<?php echo of_get_option('slideefect',true); ?>', //sliceDown, sliceDownLeft, sliceUp, sliceUpLeft, sliceUpDown, sliceUpDownLeft, fold, fade, random, slideInRight, slideInLeft, boxRandom, boxRain, boxRainReverse, boxRainGrow, boxRainGrowReverse
		  	animSpeed: <?php echo of_get_option('slideanim',true); ?>,
			pauseTime: <?php echo of_get_option('slidepause',true); ?>,
			directionNav: <?php echo of_get_option('slidenav',true); ?>,
			controlNav: <?php echo of_get_option('slidepage',true); ?>,
			pauseOnHover: <?php echo of_get_option('slidepausehover',true); ?>,
    });
});


jQuery(document).ready(function() {
  
  jQuery('.link').on('click', function(event){
    var $this = jQuery(this);
    if($this.hasClass('clicked')){
      $this.removeAttr('style').removeClass('clicked');
    } else{
      $this.css('background','#7fc242').addClass('clicked');
    }
  });
 
});
		</script>
<?php  
}
add_action('wp_head','media_css_hook'); 


function decorator_custom_head_codes() { 
	if ( function_exists('of_get_option') ){
		if ( of_get_option('style2', true) != '' ) {
			echo "<style>". esc_html( of_get_option('style2', true) ) ."</style>";
		}
		echo "<style>";
		if ( of_get_option('bodyfontface', true) != '') {
			echo 'body{font-family:\''. esc_html( of_get_option('bodyfontface', true) ) .'\';}';
		}
		if ( of_get_option('bodyfontcolor', true) != '' ) {
			echo 'body, .contact-form-section .address{color:'. esc_html( of_get_option('bodyfontcolor', true) ) .';}';
		}
		if( of_get_option('bodyfontsize',true) != ''){
			echo "body{font-size:".of_get_option('bodyfontsize',true)."}";
		}
		if( of_get_option('logofontface',true) != '' || of_get_option('logofontcolor',true) != '' || of_get_option('logofontsize',true) != ''){
			echo ".logo h1 {font-family:".of_get_option('logofontface').";color:".of_get_option('logofontcolor',true).";font-size:".of_get_option('logofontsize',true)."}";
			echo ".header_right .contact span.cell {color:".of_get_option('logofontcolor',true).";}";
		}
		if( of_get_option('logotaglinecolor',true) != '' ){
			echo ".tagline, .logo p{color:".of_get_option('logotaglinecolor',true).";}";
		}
		if( of_get_option('logoheight',true) != '' ){
			echo ".logo img{height:".of_get_option('logoheight',true)."px;}";
		}
		if( of_get_option('headertoplefticoncolor',true) != ''){
			echo ".header-top .left a .fa, .header-top .left .fa{ color:".of_get_option('headertoplefticoncolor',true).";}";
			echo ".header-top .left span.phno{ border-color:".of_get_option('headertoplefticoncolor',true).";}";
		}						
		if( of_get_option('socialfontcolor',true) != ''){
			echo ".social-icons a, .header-top .right a{ color:".of_get_option('socialfontcolor',true).";}";
		}			
		if( of_get_option('socialfonthvcolor',true) != '' || of_get_option('headertopiconhvbgcolor',true) != ''){
			echo ".social-icons a:hover, .header-top .right a:hover{ color:".of_get_option('socialfonthvcolor',true).";}";
			echo ".header-top .right a:hover{ background-color:".of_get_option('headertopiconhvbgcolor',true).";}";
		}
		if ( of_get_option('headtopiconborder', true) != '' ) {
			echo '.header-top .right a{border-color:'. esc_html( of_get_option('headtopiconborder', true) ) .';}';
		}
		if ( of_get_option('clientlogoimageborder', true) != '' ) {
			echo '.nbs-flexisel-item img{border-color:'. esc_html( of_get_option('clientlogoimageborder', true) ) .';}';
		}
		if( of_get_option('sectitlesize',true) != '' || of_get_option('sectitlecolor',true) != '' ){
			echo "h2.section_title{ font-size:".of_get_option('sectitlesize',true)."; color:".of_get_option('sectitlecolor',true)."; }";
		}
		if( of_get_option('getquotesectitlecolor',true) != '' ){
			echo ".getquote h2, .getquote p{ color:".of_get_option('getquotesectitlecolor',true)."; }";
		}		
		if ( of_get_option('navfontface', true) != '' || of_get_option('navfontsize',true) != '' ) {
			echo '.sitenav ul{font-family:\''. esc_html( of_get_option('navfontface', true) ) .'\';font-size:'.of_get_option('navfontsize',true).'}';
		}		
		if ( of_get_option('navfontcolor', true) != '' ) {
			echo '.sitenav ul li a{color:'. esc_html( of_get_option('navfontcolor', true) ) .';}';
		}		
		if ( of_get_option('navactivebgcolor', true) != '') {
			echo '.sitenav ul li a:hover, .sitenav ul li.current_page_item a, .sitenav ul li:hover a.parent{ color:'. esc_html( of_get_option('navhovercolor', true) ) .';}';
		}		
		if ( of_get_option('navdpbgcolor', true) != '' ) {
			echo ".sitenav ul li:hover > ul, .sitenav ul li a:hover, .sitenav ul li.current_page_item a{background-color:".of_get_option('navdpbgcolor',true).";}";
		}
					
		if ( of_get_option('linkcolor', true) != '' ) {
			echo 'a, .slide_toggle a, .postby a, .news-box .PostMeta a, .news-box .PostMeta span, .post-title a, .contact-cols h4 a{color:'. esc_html( of_get_option('linkcolor', true) ) .';}';
		}
		if ( of_get_option('linkhovercolor', true) != '' ) {
			echo 'a:hover, .slide_toggle a:hover, .news-box h6 a:hover, .postby a:hover, .news-box .PostMeta a:hover{color:'. esc_html( of_get_option('linkhovercolor', true) ) .';}';
		}
		if ( of_get_option('footsocialfontcolor', true) != '' || of_get_option('footersociconbgcolor', true) != '' ) {
			echo ".cols-3 .social-icons a{color:".of_get_option('footsocialfontcolor', true)."; background-color:".of_get_option('footersociconbgcolor', true)."; }";
		}
		if ( of_get_option('footsocialfontcolorhv', true) != '' || of_get_option('footersociconhvbgcolor', true) != '' ) {
			echo ".cols-3 .social-icons a:hover{ color:".of_get_option('footsocialfontcolorhv', true)."; background-color:".of_get_option('footersociconhvbgcolor', true).";}";
		}					
		if( of_get_option('foottitlecolor', true) != '' || of_get_option('ftfontsize', true) != '' || of_get_option('footerpostborder', true) != '' ){
			echo ".cols-3 h5{color:".of_get_option('foottitlecolor', true)."; font-size:".of_get_option('ftfontsize', true).";}";
			echo ".contactdetail h6{color:".of_get_option('foottitlecolor', true).";}";
			echo "ul.recent-post li{border-color:".of_get_option('footerpostborder', true)."; }";
		}
		if( of_get_option('footrecentimgbxborder', true) != ''){
			echo "ul.foot-recent li{border-color:".of_get_option('footrecentimgbxborder',true)."}";
		}
		if( of_get_option('footerconiconborder', true) != '' || of_get_option('footconiconfontcolor', true) != ''){
			echo ".foot-icon{border-color:".of_get_option('footerconiconborder',true)."}";
			echo ".contact-cols .fa{background-color:".of_get_option('footerconiconborder',true)."; color:".of_get_option('footconiconfontcolor',true)."}";
		}
		if( of_get_option('copycolor', true) != ''){
			echo ".copyright-txt, .designby{color:".of_get_option('copycolor',true)."}";
		}			
		$head_hex = of_get_option('headbgcolor','#000000');
		list($r,$g,$b) = sscanf($head_hex,'#%02x%02x%02x');
		if( of_get_option('headbgcolor',true) != '' || of_get_option('headbgopacity',true) != ''){
			echo ".header{background-color:rgba(".$r.",".$g.",".$b.",".of_get_option('headbgopacity','0.3').")}";
		}
		$head_hex = of_get_option('recentbxhvbgcolor','#ffae00');
		list($r,$g,$b) = sscanf($head_hex,'#%02x%02x%02x');
		if( of_get_option('recentbxhvbgcolor',true) != '' || of_get_option('recentbxhvbgopacity',true) != ''){
			echo ".recent-box:hover .recent-desc{background-color:rgba(".$r.",".$g.",".$b.",".of_get_option('recentbxhvbgopacity','0.9').")}";
		}
		
		if ( of_get_option('bodybgcolor', true) != '' ) {
			echo "body{background-color:".of_get_option('bodybgcolor',true)."}";
		}				
						
		if( of_get_option('btnbgcolor',true) != ''){
			echo "a.morebutton, .button, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit{background-color:".of_get_option('btnbgcolor',true).";}";
		}
		if( of_get_option('btntxtcolor', true) != ''){
			echo ".button, a.buttonstyle1, a.morebutton, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit{color:". of_get_option('btntxtcolor', true) ."; }";
		}
		if( of_get_option('btnbghvcolor',true) != '' || of_get_option('btntxthvcolor', true) != '' ){
			echo "a.morebutton:hover, .button:hover, #commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, p.read-more a:hover, .pagination ul li .current, .pagination ul li a:hover,.headertop .right a:hover, .wpcf7 form input[type='submit']:hover{background-color:".of_get_option('btnbghvcolor',true)."; color:". esc_html( of_get_option('btntxthvcolor', true) ) .";}";			
		}
		if ( of_get_option('readmorebuttonborder', true) != '' || of_get_option('readmorebuttonhvborder', true) != '' ) {
			echo "a.buttonstyle1{border-color:".of_get_option('readmorebuttonborder', true)."; }";
			echo "a.buttonstyle1:hover{border-color:".of_get_option('readmorebuttonhvborder', true)."; background-color:".of_get_option('readmorebuttonhvborder', true)."; }";
		}
		if( of_get_option('recentbxviewbtnbgcolor',true) != '' ){
			echo ".recent-box:hover .view{background-color:".of_get_option('recentbxviewbtnbgcolor',true).";}";
		}		
				
		if ( of_get_option('widgetboxbgcolor', true) != '' || of_get_option('widgetboxfontcolor', true) != '' ) {
		echo "aside.widget, #sidebar .search-form input.search-field, .contact_right #testimonials, .contact_right .contactdetail{ background-color:".of_get_option('widgetboxbgcolor', true)."; color:".of_get_option('widgetboxfontcolor', true).";  }";
		}
		if ( of_get_option('widgettitlebgcolor', true) != '' || of_get_option('wdgttitleccolor', true) != '' ) {
			echo "h3.widget-title{ background-color:".of_get_option('widgettitlebgcolor', true)."; color:".of_get_option('wdgttitleccolor', true).";}";
		}
		if ( of_get_option('footertopbgcolor', true) != '') {
			echo "#footer-contact{background-color:".of_get_option('footertopbgcolor', true).";}";
		}
		if ( of_get_option('footerbgcolor', true) != '' || of_get_option('footdesccolor', true) != '' ) {
			echo "#footer-wrapper{background-color:".of_get_option('footerbgcolor', true)."; color:".of_get_option('footdesccolor', true).";}";
			echo ".cols-3 ul li a{color:".of_get_option('footdesccolor', true).";}";
		}		
				
		if ( of_get_option('footermenucolor', true) != '' ) {
			echo ".contactdetail a:hover, .cols-3 ul li a:hover{color:".of_get_option('footermenucolor', true)."; }";
		}
		if ( of_get_option('footdesccolor', true) != '' ) {
			echo ".contactdetail a{color:".of_get_option('footdesccolor', true)."; }";
		}			
		if ( of_get_option('copybgcolor', true) != '' ) {
			echo '.copyright-wrapper{background-color:'. esc_html( of_get_option('copybgcolor', true) ) .';}';
		}		
		
		if( of_get_option('sldpagebg',true) != ''){
			echo ".nivo-controlNav a{background-color:".of_get_option('sldpagebg',true)."}";
		}
		if( of_get_option('sldpagehvbg',true) != ''){
			echo ".nivo-controlNav a.active{background-color:".of_get_option('sldpagehvbg',true)."}";
		}	
		if( of_get_option('sldpagehvbd',true) != ''){
			echo ".nivo-controlNav a{border-color:".of_get_option('sldpagehvbd',true)."}";
		}
		if( of_get_option('sidebarliaborder', true) != '' ){
			echo "#sidebar ul li{border-color:".of_get_option('sidebarliaborder',true)."}";
		}	
		if( of_get_option('sidebarfontcolor',true) != '' ){
			echo "#sidebar ul li a{color:".of_get_option('sidebarfontcolor',true)."; }";
		}		
		if( of_get_option('sidebarfonthvcolor',true) != '' ){
			echo "#sidebar ul li a:hover{color:".of_get_option('sidebarfonthvcolor',true)."; }";
		}	
			
		if ( of_get_option('slidetitlefontface', true) != '' || of_get_option('slidetitlecolor', true) != '' || of_get_option('slidetitlefontsize', true) != '') {
		echo ".nivo-caption h2{ font-family:".of_get_option('slidetitlefontface', true)."; color:".of_get_option('slidetitlecolor', true)."; font-size:".of_get_option('slidetitlefontsize', true).";}";
		}
		if ( of_get_option('slidesmtitlefontface', true) != '' || of_get_option('slidesmtitlecolor', true) != '' || of_get_option('slidesmtitlefontsize', true) != '') {
		echo ".nivo-caption h6{ font-family:".of_get_option('slidesmtitlefontface', true)."; color:".of_get_option('slidesmtitlecolor', true)."; font-size:".of_get_option('slidesmtitlefontsize', true).";}";
		}
		if ( of_get_option('slidedesfontface', true) != '' || of_get_option('slidedesccolor', true) != '' || of_get_option('slidedescfontsize', true) != '') {
		echo ".nivo-caption p{font-family:".of_get_option('slidedesfontface', true)."; color:".of_get_option('slidedesccolor', true)."; font-size:".of_get_option('slidedescfontsize', true).";}";
		}
		if ( of_get_option('copylinks', true) != '' ) {
		echo ".copyright-wrapper a{ color: ".of_get_option('copylinks', true)."; }";
		}	
				
		if ( of_get_option('togglemenu', true) != '' || of_get_option('togglemenucolor', true) != '' ) {
		echo ".toggle a{ background-color:".of_get_option('togglemenu', true)."; color:".of_get_option('togglemenucolor', true)."; }";
		}
		if ( of_get_option('recentbxhvtitlecolor', true) != '' ) {
			echo ".recent-desc h3, .recent-desc .view{ color:".of_get_option('recentbxhvtitlecolor', true)."; }";
		}
				
		
/* Heading */
		if( of_get_option('headfontface', true) != '' ){
			echo "h1,h2,h3,h4,h5,h6{ font-family:".of_get_option('headfontface',true)."; }";
		}		
		if ( of_get_option('h1fontsize', true) != '' || of_get_option('h1fontcolor', true) != '' ) {
			echo "h1{ font-size:".of_get_option('h1fontsize', true)."; color:".of_get_option('h1fontcolor', true).";}";
		}
		if ( of_get_option('h2fontsize', true) != '' || of_get_option('h2fontcolor', true) != '' ) {
			echo "h2{ font-size:".of_get_option('h2fontsize', true)."; color:".of_get_option('h2fontcolor', true).";}";
		}		
		if ( of_get_option('h3fontsize', true) != '' || of_get_option('h3fontcolor', true) != '' ) {
			echo "h3{ font-size:".of_get_option('h3fontsize', true)."; color:".of_get_option('h3fontcolor', true).";}";
		}		
		if ( of_get_option('h4fontsize', true) != '' || of_get_option('h4fontcolor', true) != '' ) {
			echo "h4{ font-size:".of_get_option('h4fontsize', true)."; color:".of_get_option('h4fontcolor', true).";}";
		}		
		if ( of_get_option('h5fontsize', true) != '' || of_get_option('h5fontcolor', true) != '' ) {
			echo "h5{font-size:".of_get_option('h5fontsize', true)."; color:".of_get_option('h5fontcolor', true).";}";
		}		
		if ( of_get_option('h6fontsize', true) != '' || of_get_option('h6fontcolor', true) != '' ) {
			echo "h6{ font-size:".of_get_option('h6fontsize', true)."; color:".of_get_option('h6fontcolor', true).";}";
		}
/* Custom editable */
			
		if ( of_get_option('headertopbgcolor', true) != '' || of_get_option('headertopcolor', true) != '' ) {
			echo ".header-top{ background-color:".of_get_option('headertopbgcolor', true)."; color:".of_get_option('headertopcolor', true).";}";
			echo ".header-top .left span a{ color:".of_get_option('headertopcolor', true).";}";			
		}
		if ( of_get_option('headconpagebgcolor', true) != '') {
			echo ".header.contacthead{ background-color:".of_get_option('headconpagebgcolor', true).";}";					
		}
					
		$sliderarrowhex = of_get_option('sldarrowbg',true); 
		list($r,$g,$b) = sscanf($sliderarrowhex,'#%02x%02x%02x');
		if ( of_get_option('sldarrowbg', true) != '' ) {
			echo ".nivo-directionNav a{background-color:rgba(".$r.",".$g.",".$b.",".of_get_option('sldarrowopacity',true).");}";
		}				
		
		// Top Four Boxes CSS
		if (of_get_option('hometopfourbxbdrcolor', true) != '') {
			echo ".fourbox{ border-color:".of_get_option('hometopfourbxbdrcolor', true)."; }";
			echo ".fourbox:hover .fourbxcontent{ background-color:".of_get_option('hometopfourbxbdrcolor', true)."; }";
		} 
		if (of_get_option('hometopfourbxcolor', true) != '') {
			echo ".fourbox{ color:".of_get_option('hometopfourbxcolor', true)."; }";
		}
		if ( of_get_option('hometopfourbxtitlecolor', true) != '') {
			echo ".fourbox h3{ color:".of_get_option('hometopfourbxtitlecolor', true)."; }";
			echo ".fourbox .fourbxcontent{ border-color:".of_get_option('hometopfourbxtitlecolor', true)."; }";
		}						
		if ( of_get_option('hometopfourbxhvreadmorebtn', true) != '' ) {
			echo ".fourbox:hover .pagemore{ border-color:".of_get_option('hometopfourbxhvreadmorebtn', true)."; }";
		}
		
		// Portfolio Gallery 
		if( of_get_option('holdwrapbgcolor',true) != ''){
			echo ".holderwrap{background-color:".of_get_option('holdwrapbgcolor',true).";}";			
		}
		if( of_get_option('filtertabselectedbgcolor',true) != ''){
			echo "ul.portfoliofilter li a.selected{background-color:".of_get_option('filtertabselectedbgcolor',true)."; border-color:".of_get_option('filtertabselectedbgcolor',true).";}";			
		}
		if( of_get_option('filtertabfontcolor',true) != ''){
			echo "ul.portfoliofilter li a{color:".of_get_option('filtertabfontcolor',true)."; border-color:".of_get_option('filtertabfontcolor',true).";}";			
		}
		if( of_get_option('filtertabhvbgcolor',true) != ''){
			echo "ul.portfoliofilter li:hover a, ul.portfoliofilter li a:hover{background-color:".of_get_option('filtertabhvbgcolor',true)."; border-color:".of_get_option('filtertabhvbgcolor',true).";}";			
		}
				
		// Tab and Accourdian CSS 
		if ( of_get_option('tabbgcolor', true) != '' || of_get_option('tabfontcolor', true) != '' ) {
			echo ".tabs-wrapper ul.tabs li a{ background-color:".of_get_option('tabbgcolor', true)."; color:".of_get_option('tabfontcolor', true)."; }";
		}		
		if ( of_get_option('tabbgcolorhv', true) != '' || of_get_option('tabfontcolorhv', true) != '' ) {
			echo ".tabs-wrapper ul.tabs li a.selected{ background-color:".of_get_option('tabbgcolorhv', true)."; color:".of_get_option('tabfontcolorhv', true)."; }";
		}		
		if ( of_get_option('tabcontentborder', true) != '' || of_get_option('tabcontentfontcolor', true) != '' ) {
			echo ".tabs-wrapper .tab-content{ border-color:".of_get_option('tabcontentborder', true)."; color:".of_get_option('tabcontentfontcolor', true)."; }";
		}
		if ( of_get_option('acctitlebordercolor', true) != '' || of_get_option('acctitlecolor', true) != '' ) {
			echo ".accordion-box h2{ border-color:".of_get_option('acctitlebordercolor', true)."; color:".of_get_option('acctitlecolor', true)."; }";
		}		
		if ( of_get_option('acctitlebgcolorhv', true) != '' || of_get_option('acctitlecolorhv', true) != '' ) {
			echo ".accordion-box h2.active{ background-color:".of_get_option('acctitlebgcolorhv', true)."; color:".of_get_option('acctitlecolorhv', true)."; }";
		}
		if ( of_get_option('accdescbgcolor', true) != '' || of_get_option('accdescfontcolor', true) != '' ) {
			echo ".acc-content{ background-color:".of_get_option('accdescbgcolor', true)."; color:".of_get_option('accdescfontcolor', true)."; }";
		}				
		
		//Testimonials CSS
		if ( of_get_option('testidotsbgcolor', true) != '' ) {
			echo ".owl-controls .owl-dot{ background-color:".of_get_option('testidotsbgcolor', true)."; }";
		}
		if ( of_get_option('testidotsbgcolorhv', true) != '' ) {
			echo ".owl-controls .owl-dot.active{ background-color:".of_get_option('testidotsbgcolorhv', true)."; }";
		}				
		if ( of_get_option('testimonialtitlecolor', true) != '' ) {
			echo "#clienttestiminials h6, #clienttestiminials h6 a{ color:".of_get_option('testimonialtitlecolor', true)."; }";
		}
		if ( of_get_option('testimonialdesccolor', true) != '' ) {
			echo "#clienttestiminials p{ color:".of_get_option('testimonialdesccolor', true)."; }";
		}
		if ( of_get_option('testimonialtitlecomp', true) != '' ) {
			echo "#clienttestiminials span{ color:".of_get_option('testimonialtitlecomp', true)."; }";
		}
		
		//Academics News CSS
		if ( of_get_option('latestpoststtlcolor', true) != '' ) {
			echo ".news-box h6 a{ color:".of_get_option('latestpoststtlcolor', true)."; }";
		}
		if ( of_get_option('postmeta', true) != '' ) {
			echo ".news-box .PostMeta{ color:".of_get_option('postmeta', true)."; }";
		}
		
		//Skill Bar CSS
		if ( of_get_option('skillbarbgcolor', true) != '' ) {
			echo ".skill-bg{ background-color:".of_get_option('skillbarbgcolor', true)."; }";
		}
		if ( of_get_option('skillbarbgcoloractive', true) != '' ) {
			echo ".skillbar-bar{ background-color:".of_get_option('skillbarbgcoloractive', true)." !important; }";
		}		
				
		echo "</style>";
	}
}
add_action('wp_head', 'decorator_custom_head_codes');


function decorator_pagination() {
	global $wp_query;
	$big = 12345678;
	$page_format = paginate_links( array(
	    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	    'format' => '?paged=%#%',
	    'current' => max( 1, get_query_var('paged') ),
	    'total' => $wp_query->max_num_pages,
	    'type'  => 'array'
	) );
	if( is_array($page_format) ) {
		$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
		echo '<div class="pagination"><div><ul>';
		echo '<li><span>'. $paged . ' of ' . $wp_query->max_num_pages .'</span></li>';
		foreach ( $page_format as $page ) {
			echo "<li>$page</li>";
		}
		echo '</ul></div></div>';
	}
}
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';


/**
 * Load custom functions file.
 */
require get_template_directory() . '/inc/custom-functions.php';

function decorator_custom_blogpost_pagination( $wp_query ){
	$big = 999999999; // need an unlikely integer
	if ( get_query_var('paged') ) { $pageVar = 'paged'; }
	elseif ( get_query_var('page') ) { $pageVar = 'page'; }
	else { $pageVar = 'paged'; }
	$pagin = paginate_links( array(
		'base' 			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' 		=> '?'.$pageVar.'=%#%',
		'current' 		=> max( 1, get_query_var($pageVar) ),
		'total' 		=> $wp_query->max_num_pages,
		'prev_text'		=> '&laquo; Prev',
		'next_text' 	=> 'Next &raquo;',
		'type'  => 'array'
	) ); 
	if( is_array($pagin) ) {
		$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
		echo '<div class="pagination"><div><ul>';
		echo '<li><span>'. $paged . ' of ' . $wp_query->max_num_pages .'</span></li>';
		foreach ( $pagin as $page ) {
			echo "<li>$page</li>";
		}
		echo '</ul></div></div>';
	} 
}
// get slug by id
function decorator_get_slug_by_id($id) {
	$post_data = get_post($id, ARRAY_A);
	$slug = $post_data['post_name'];
	return $slug; 
}