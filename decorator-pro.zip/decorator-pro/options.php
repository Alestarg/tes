<?php 
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 * By default it uses the theme name, in lowercase and without spaces, but this can be changed if needed.
 * If the identifier changes, it'll appear as if the options have been reset.
 */ 

function optionsframework_option_name() {
	// Change this to use your theme slug
	$themename = wp_get_theme();
	$themename = preg_replace("/\W/", "_", strtolower($themename) );
	return $themename;
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'decorator'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
*/

function optionsframework_options() {
	//array of all custom font types.
	$font_types = array( '' => '',
    'ABeeZee' => 'ABeeZee',
    'Abel' => 'Abel',
    'Abril Fatface' => 'Abril Fatface',
    'Aclonica' => 'Aclonica',
    'Acme' => 'Acme',
    'Actor' => 'Actor',
    'Adamina' => 'Adamina',
    'Advent Pro' => 'Advent Pro',
    'Aguafina Script' => 'Aguafina Script',
    'Akronim' => 'Akronim',
    'Aladin' => 'Aladin',
    'Aldrich' => 'Aldrich',
    'Alegreya' => 'Alegreya',
    'Alegreya Sans SC' => 'Alegreya Sans SC',
    'Alegreya SC' => 'Alegreya SC',
    'Alex Brush' => 'Alex Brush',
    'Alef' => 'Alef',
    'Alfa Slab One' => 'Alfa Slab One',
    'Alice' => 'Alice',
    'Alike' => 'Alike',
    'Alike Angular' => 'Alike Angular',
    'Allan' => 'Allan',
    'Allerta' => 'Allerta',
    'Allerta Stencil' => 'Allerta Stencil',
    'Allura' => 'Allura',
    'Almendra' => 'Almendra',
    'Almendra Display' => 'Almendra Display',
    'Almendra SC' => 'Almendra SC',
    'Amiri' => 'Amiri',
    'Amarante' => 'Amarante',
    'Amaranth' => 'Amaranth',
    'Amatic SC' => 'Amatic SC',
    'Amethysta' => 'Amethysta',
    'Amita' => 'Amita',
    'Anaheim' => 'Anaheim',
    'Andada' => 'Andada',
    'Andika' => 'Andika',
    'Annie Use Your Telescope' => 'Annie Use Your Telescope',
    'Anonymous Pro' => 'Anonymous Pro',
    'Antic' => 'Antic',
    'Antic Didone' => 'Antic Didone',
    'Antic Slab' => 'Antic Slab',
    'Anton' => 'Anton',
    'Angkor' => 'Angkor',
    'Arapey' => 'Arapey',
    'Arbutus' => 'Arbutus',
    'Arbutus Slab' => 'Arbutus Slab',
    'Architects Daughter' => 'Architects Daughter',
    'Archivo White' => 'Archivo White',
    'Archivo Narrow' => 'Archivo Narrow',
    'Arial' => 'Arial',
    'Arimo' => 'Arimo',
    'Arya' => 'Arya',
    'Arizonia' => 'Arizonia',
    'Armata' => 'Armata',
    'Artifika' => 'Artifika',
    'Arvo' => 'Arvo',
    'Asar' => 'Asar',
    'Asap' => 'Asap',
    'Asset' => 'Asset',
    'Astloch' => 'Astloch',
    'Asul' => 'Asul',
    'Atomic Age' => 'Atomic Age',
    'Aubrey' => 'Aubrey',
    'Audiowide' => 'Audiowide',
    'Autour One' => 'Autour One',
    'Average' => 'Average',
    'Average Sans' => 'Average Sans',
    'Averia Gruesa Libre' => 'Averia Gruesa Libre',
    'Averia Libre' => 'Averia Libre',
    'Averia Sans Libre' => 'Averia Sans Libre',
    'Averia Serif Libre' => 'Averia Serif Libre',
    'Battambang' => 'Battambang',
    'Bad Script' => 'Bad Script',
    'Bayon' => 'Bayon',
    'Balthazar' => 'Balthazar',
    'Bangers' => 'Bangers',
    'Basic' => 'Basic',
    'Baumans' => 'Baumans',
    'Belgrano' => 'Belgrano',
    'Belleza' => 'Belleza',
    'BenchNine' => 'BenchNine',
    'Bentham' => 'Bentham',
    'Berkshire Swash' => 'Berkshire Swash',
    'Bevan' => 'Bevan',
    'Bigelow Rules' => 'Bigelow Rules',
    'Bigshot One' => 'Bigshot One',
    'Bilbo' => 'Bilbo',
    'Bilbo Swash Caps' => 'Bilbo Swash Caps',
    'Biryani' => 'Biryani',
    'Bitter' => 'Bitter',
    'White Ops One' => 'White Ops One',
    'Bokor' => 'Bokor',
    'Bonbon' => 'Bonbon',
    'Boogaloo' => 'Boogaloo',
    'Bowlby One' => 'Bowlby One',
    'Bowlby One SC' => 'Bowlby One SC',
    'Brawler' => 'Brawler',
    'Bree Serif' => 'Bree Serif',
    'Bubblegum Sans' => 'Bubblegum Sans',
    'Bubbler One' => 'Bubbler One',
    'Buda' => 'Buda',
    'Buenard' => 'Buenard',
    'Butcherman' => 'Butcherman',
    'Butcherman Caps' => 'Butcherman Caps',
    'Butterfly Kids' => 'Butterfly Kids',
    'Cabin' => 'Cabin',
    'Cabin Condensed' => 'Cabin Condensed',
    'Cabin Sketch' => 'Cabin Sketch',
    'Cabin' => 'Cabin',
    'Caesar Dressing' => 'Caesar Dressing',
    'Cagliostro' => 'Cagliostro',
    'Calligraffitti' => 'Calligraffitti',
    'Cambay' => 'Cambay',
    'Cambo' => 'Cambo',
    'Candal' => 'Candal',
    'Cantarell' => 'Cantarell',
    'Cantata One' => 'Cantata One',
    'Cantora One' => 'Cantora One',
    'Capriola' => 'Capriola',
    'Cardo' => 'Cardo',
    'Carme' => 'Carme',
    'Carrois Gothic' => 'Carrois Gothic',
    'Carrois Gothic SC' => 'Carrois Gothic SC',
    'Carter One' => 'Carter One',
    'Caveat' => 'Caveat',
    'Caveat Brush' => 'Caveat Brush',
    'Catamaran' => 'Catamaran',
    'Caudex' => 'Caudex',
    'Cedarville Cursive' => 'Cedarville Cursive',
    'Ceviche One' => 'Ceviche One',
    'Changa One' => 'Changa One',
    'Chango' => 'Chango',
    'Chau Philomene One' => 'Chau Philomene One',
    'Chenla' => 'Chenla',
    'Chela One' => 'Chela One',
    'Chelsea Market' => 'Chelsea Market',
    'Cherry Cream Soda' => 'Cherry Cream Soda',
    'Cherry Swash' => 'Cherry Swash',
    'Chewy' => 'Chewy',
    'Chicle' => 'Chicle',
    'Chivo' => 'Chivo',
    'Chonburi' => 'Chonburi',
    'Cinzel' => 'Cinzel',
    'Cinzel Decorative' => 'Cinzel Decorative',
    'Clicker Script' => 'Clicker Script',
    'Coda' => 'Coda',
    'Codystar' => 'Codystar',
    'Combo' => 'Combo',
    'Comfortaa' => 'Comfortaa',
    'Coming Soon' => 'Coming Soon',
    'Condiment' => 'Condiment',
    'Content' => 'Content',
    'Contrail One' => 'Contrail One',
    'Convergence' => 'Convergence',
    'Cookie' => 'Cookie',
    'Comic Sans MS' => 'Comic Sans MS',
    'Copse' => 'Copse',
    'Corben' => 'Corben',
    'Courgette' => 'Courgette',
    'Cousine' => 'Cousine',
    'Coustard' => 'Coustard',
    'Covered By Your Krayon' => 'Covered By Your Krayon',
    'Crafty Girls' => 'Crafty Girls',
    'Creepster' => 'Creepster',
    'Creepster Caps' => 'Creepster Caps',
    'Crete Round' => 'Crete Round',
    'Crimson' => 'Crimson',
    'Croissant One' => 'Croissant One',
    'Crushed' => 'Crushed',
    'Cuprum' => 'Cuprum',
    'Cutive' => 'Cutive',
    'Cutive Mono' => 'Cutive Mono',
    'Damion' => 'Damion',
    'Dangrek' => 'Dangrek',
    'Dancing Script' => 'Dancing Script',
    'Dawning of a New Day' => 'Dawning of a New Day',
    'Days One' => 'Days One',
    'Dekko' => 'Dekko',
    'Delius' => 'Delius',
    'Delius Swash Caps' => 'Delius Swash Caps',
    'Delius Unicase' => 'Delius Unicase',
    'Della Respira' => 'Della Respira',
    'Denk One' => 'Denk One',
    'Devonshire' => 'Devonshire',
    'Dhurjati' => 'Dhurjati',
    'Didact Gothic' => 'Didact Gothic',
    'Diplomata' => 'Diplomata',
    'Diplomata SC' => 'Diplomata SC',
    'Domine' => 'Domine',
    'Donegal One' => 'Donegal One',
    'Doppio One' => 'Doppio One',
    'Dorsa' => 'Dorsa',
    'Dosis' => 'Dosis',
    'Dr Sugiyama' => 'Dr Sugiyama',
    'Droid Sans' => 'Droid Sans',
    'Droid Sans Mono' => 'Droid Sans Mono',
    'Droid Serif' => 'Droid Serif',
    'Duru Sans' => 'Duru Sans',
    'Dynalight' => 'Dynalight',
    'EB Garamond' => 'EB Garamond',
    'Eczar' => 'Eczar',
    'Eagle Lake' => 'Eagle Lake',
    'Eater' => 'Eater',
    'Eater Caps' => 'Eater Caps',
    'Economica' => 'Economica',
    'Ek Mukta' => 'Ek Mukta',
    'Electrolize' => 'Electrolize',
    'Elsie' => 'Elsie',
    'Elsie Swash Caps' => 'Elsie Swash Caps',
    'Emblema One' => 'Emblema One',
    'Emilys Candy' => 'Emilys Candy',
    'Engagement' => 'Engagement',
    'Englebert' => 'Englebert',
    'Enriqueta' => 'Enriqueta',
    'Erica One' => 'Erica One',
    'Esteban' => 'Esteban',
    'Euphoria Script' => 'Euphoria Script',
    'Ewert' => 'Ewert',
    'Exo' => 'Exo',
    'Exo 2' => 'Exo 2',
    'Expletus Sans' => 'Expletus Sans',
    'Fanwood Text' => 'Fanwood Text',
    'Fascinate' => 'Fascinate',
    'Fascinate Inline' => 'Fascinate Inline',
    'Fasthand' => 'Fasthand',
    'Faster One' => 'Faster One',
    'Federant' => 'Federant',
    'Federo' => 'Federo',
    'Felipa' => 'Felipa',
    'Fenix' => 'Fenix',
    'Finger Paint' => 'Finger Paint',
    'Fira Mono' => 'Fira Mono',
    'Fira Sans' => 'Fira Sans',
    'Fjalla One' => 'Fjalla One',
    'Fjord One' => 'Fjord One',
    'Flamenco' => 'Flamenco',
    'Flavors' => 'Flavors',
    'Fondamento' => 'Fondamento',
    'Fontdiner Swanky' => 'Fontdiner Swanky',
    'Forum' => 'Forum',
    'Francois One' => 'Francois One',
    'FreeSans' => 'FreeSans',

    'Freckle Face' => 'Freckle Face',
    'Fredericka the Great' => 'Fredericka the Great',
    'Fredoka One' => 'Fredoka One',
    'Fresca' => 'Fresca',
    'Freehand' => 'Freehand',
    'Frijole' => 'Frijole',
    'Fruktur' => 'Fruktur',
    'Fugaz One' => 'Fugaz One',
    'Gafata' => 'Gafata',
    'Galdeano' => 'Galdeano',
    'Galindo' => 'Galindo',
    'Gentium Basic' => 'Gentium Basic',
    'Gentium Book Basic' => 'Gentium Book Basic',
    'Geo' => 'Geo',
    'Georgia' => 'Georgia',
    'Geostar' => 'Geostar',
    'Geostar Fill' => 'Geostar Fill',
    'Germania One' => 'Germania One',
    'Gilda Display' => 'Gilda Display',
    'Give You Glory' => 'Give You Glory',
    'Glass Antiqua' => 'Glass Antiqua',
    'Glegoo' => 'Glegoo',
    'Gloria Hallelujah' => 'Gloria Hallelujah',
    'Goblin One' => 'Goblin One',
    'Gochi Hand' => 'Gochi Hand',
    'Gorditas' => 'Gorditas',
    'Gurajada' => 'Gurajada',
    'Goudy Bookletter 1911' => 'Goudy Bookletter 1911',
    'Graduate' => 'Graduate',
    'Grand Hotel' => 'Grand Hotel',
    'Gravitas One' => 'Gravitas One',
    'Great Vibes' => 'Great Vibes',
    'Griffy' => 'Griffy',
    'Gruppo' => 'Gruppo',
    'Gudea' => 'Gudea',
    'Gidugu' => 'Gidugu',
    'GFS Didot' => 'GFS Didot',
    'GFS Neohellenic' => 'GFS Neohellenic',
    'Habibi' => 'Habibi',
    'Hammersmith One' => 'Hammersmith One',
    'Halant' => 'Halant',
    'Hanalei' => 'Hanalei',
    'Hanalei Fill' => 'Hanalei Fill',
    'Handlee' => 'Handlee',
    'Hanuman' => 'Hanuman',
    'Happy Monkey' => 'Happy Monkey',
    'Headland One' => 'Headland One',
    'Henny Penny' => 'Henny Penny',
    'Herr Von Muellerhoff' => 'Herr Von Muellerhoff',
    'Hind' => 'Hind',
    'Hind Siliguri' => 'Hind Siliguri',
    'Hind Vadodara' => 'Hind Vadodara',
    'Holtwood One SC' => 'Holtwood One SC',
    'Homemade Apple' => 'Homemade Apple',
    'Homenaje' => 'Homenaje',
    'IM Fell' => 'IM Fell',
    'Itim' => 'Itim',
    'Iceberg' => 'Iceberg',
    'Iceland' => 'Iceland',
    'Imprima' => 'Imprima',
    'Inconsolata' => 'Inconsolata',
    'Inder' => 'Inder',
    'Indie Flower' => 'Indie Flower',
    'Inknut Antiqua' => 'Inknut Antiqua',
    'Inika' => 'Inika',
    'Irish Growler' => 'Irish Growler',
    'Istok Web' => 'Istok Web',
    'Italiana' => 'Italiana',
    'Italianno' => 'Italianno',
    'Jacques Francois' => 'Jacques Francois',
    'Jacques Francois Shadow' => 'Jacques Francois Shadow',
    'Jim Nightshade' => 'Jim Nightshade',
    'Jockey One' => 'Jockey One',
    'Jaldi' => 'Jaldi',
    'Jolly Lodger' => 'Jolly Lodger',
    'Josefin Sans' => 'Josefin Sans',
    'Josefin Sans' => 'Josefin Sans',
    'Josefin Slab' => 'Josefin Slab',
    'Joti One' => 'Joti One',
    'Judson' => 'Judson',
    'Julee' => 'Julee',
    'Julius Sans One' => 'Julius Sans One',
    'Junge' => 'Junge',
    'Jura' => 'Jura',
    'Just Another Hand' => 'Just Another Hand',
    'Just Me Again Down Here' => 'Just Me Again Down Here',
    'Kadwa' => 'Kadwa',
    'Kdam Thmor' => 'Kdam Thmor',
    'Kalam' => 'Kalam', 
    'Kameron' => 'Kameron',
    'Kantumruy' => 'Kantumruy',
    'Karma' => 'Karma',
    'Karla' => 'Karla',
    'Kaushan Script' => 'Kaushan Script',
    'Kavoon' => 'Kavoon',
    'Keania One' => 'Keania One',
    'Kelly Slab' => 'Kelly Slab',
    'Kenia' => 'Kenia',
    'Khand' => 'Khand',
    'Khmer' => 'Khmer',
    'Khula' => 'Khula',
    'Kite One' => 'Kite One',
    'Knewave' => 'Knewave',
    'Kotta One' => 'Kotta One',
    'Kranky' => 'Kranky',
    'Kreon' => 'Kreon',
    'Kristi' => 'Kristi',
    'Koulen' => 'Koulen',
    'Krona One' => 'Krona One',
    'Kurale' => 'Kurale',
    'Lakki Reddy' => 'Lakki Reddy',
    'La Belle Aurore' => 'La Belle Aurore',
    'Lancelot' => 'Lancelot',
    'Laila' => 'Laila',
    'Lato' => 'Lato',
    'Lateef' => 'Lateef',
    'League Script' => 'League Script',
    'Leckerli One' => 'Leckerli One',
    'Ledger' => 'Ledger',
    'Lekton' => 'Lekton',
    'Lemon' => 'Lemon',

    'Libre Baskerville' => 'Libre Baskerville',
    'Life Savers' => 'Life Savers',
    'Lilita One' => 'Lilita One',
    'Limelight' => 'Limelight',
    'Linden Hill' => 'Linden Hill',
    'Lobster' => 'Lobster',
    'Lobster Two' => 'Lobster Two',
    'Londrina Outline' => 'Londrina Outline',
    'Londrina Shadow' => 'Londrina Shadow',
    'Londrina Sketch' => 'Londrina Sketch',
    'Londrina Solid' => 'Londrina Solid',
    'Lora' => 'Lora',
    'Love Ya Like A Sister' => 'Love Ya Like A Sister',
    'Loved by the King' => 'Loved by the King',
    'Lovers Quarrel' => 'Lovers Quarrel',
    'Lucida Sans Unicode' => 'Lucida Sans Unicode',
    'Luckiest Guy' => 'Luckiest Guy',
    'Lusitana' => 'Lusitana',
    'Lustria' => 'Lustria',
    'Macondo' => 'Macondo',
    'Macondo Swash Caps' => 'Macondo Swash Caps',
    'Magra' => 'Magra',
    'Maiden Orange' => 'Maiden Orange',
    'Mallanna' => 'Mallanna',
    'Mandali' => 'Mandali',
    'Mako' => 'Mako',
    'Marcellus' => 'Marcellus',
    'Marcellus SC' => 'Marcellus SC',
    'Marck Script' => 'Marck Script',
    'Margarine' => 'Margarine',
    'Marko One' => 'Marko One',
    'Marmelad' => 'Marmelad',
    'Marvel' => 'Marvel',
    'Martel' => 'Martel',
    'Martel Sans' => 'Martel Sans',
    'Mate' => 'Mate',
    'Mate SC' => 'Mate SC',
    'Maven Pro' => 'Maven Pro',
    'McLaren' => 'McLaren',
    'Meddon' => 'Meddon',
    'MedievalSharp' => 'MedievalSharp',
    'Medula One' => 'Medula One',
    'Megrim' => 'Megrim',
    'Meie Script' => 'Meie Script',
    'Merienda' => 'Merienda',
    'Merienda One' => 'Merienda One',
    'Merriweather' => 'Merriweather',
    'Metal' => 'Metal',
    'Metal Mania' => 'Metal Mania',
    'Metamorphous' => 'Metamorphous',
    'Metrophobic' => 'Metrophobic',
    'Michroma' => 'Michroma',
    'Milonga' => 'Milonga',
    'Miltonian' => 'Miltonian',
    'Miltonian Tattoo' => 'Miltonian Tattoo',
    'Miniver' => 'Miniver',
    'Miss Fajardose' => 'Miss Fajardose',
    'Miss Saint Delafield' => 'Miss Saint Delafield',
    'Modak' => 'Modak',
    'Modern Antiqua' => 'Modern Antiqua',
    'Molengo' => 'Molengo',
    'Molle' => 'Molle',
    'Moulpali' => 'Moulpali',
    'Monda' => 'Monda',
    'Monofett' => 'Monofett',
    'Monoton' => 'Monoton',
    'Monsieur La Doulaise' => 'Monsieur La Doulaise',
    'Montaga' => 'Montaga',
    'Montez' => 'Montez',
    'Montserrat' => 'Montserrat',
    'Montserrat Alternates' => 'Montserrat Alternates',
    'Montserrat Subrayada' => 'Montserrat Subrayada',
    'Mountains of Christmas' => 'Mountains of Christmas',
    'Mouse Memoirs' => 'Mouse Memoirs',
    'Moul' => 'Moul',
    'Mr Bedford' => 'Mr Bedford',
    'Mr Bedfort' => 'Mr Bedfort',
    'Mr Dafoe' => 'Mr Dafoe',
    'Mr De Haviland' => 'Mr De Haviland',
    'Mrs Saint Delafield' => 'Mrs Saint Delafield',
    'Mrs Sheppards' => 'Mrs Sheppards',
    'Muli' => 'Muli',
    'Mystery Quest' => 'Mystery Quest',
    'Neucha' => 'Neucha',
    'Neuton' => 'Neuton',
    'New Rocker' => 'New Rocker',
    'News Cycle' => 'News Cycle',
    'Niconne' => 'Niconne',
    'Nixie One' => 'Nixie One',
    'Nobile' => 'Nobile',
    'Nokora' => 'Nokora',
    'Norican' => 'Norican',
    'Nosifer' => 'Nosifer',
    'Nosifer Caps' => 'Nosifer Caps',
    'Nova Mono' => 'Nova Mono',
    'Noticia Text' => 'Noticia Text',
    'Noto Sans' => 'Noto Sans',
    'Noto Serif' => 'Noto Serif',
    'Nova Round' => 'Nova Round',
    'Numans' => 'Numans',
    'Nunito' => 'Nunito',
    'NTR' => 'NTR',
    'Offside' => 'Offside',
    'Oldenburg' => 'Oldenburg',
    'Oleo Script' => 'Oleo Script',
    'Oleo Script Swash Caps' => 'Oleo Script Swash Caps',
    'Open Sans' => 'Open Sans',
    'Open Sans Condensed' => 'Open Sans Condensed',
    'Oranienbaum' => 'Oranienbaum',
    'Orbitron' => 'Orbitron',
    'Odor Mean Chey' => 'Odor Mean Chey',
    'Oregano' => 'Oregano',
    'Orienta' => 'Orienta',
    'Original Surfer' => 'Original Surfer',
    'Oswald' => 'Oswald',
    'Over the Rainbow' => 'Over the Rainbow',
    'Overlock' => 'Overlock',
    'Overlock SC' => 'Overlock SC',
    'Ovo' => 'Ovo',
    'Oxygen' => 'Oxygen',
    'Oxygen Mono' => 'Oxygen Mono',
    'Palanquin Dark' => 'Palanquin Dark',
    'Peddana' => 'Peddana',
    'Poppins' => 'Poppins',
    'PT Mono' => 'PT Mono',
    'PT Sans' => 'PT Sans',
    'PT Sans Caption' => 'PT Sans Caption',
    'PT Sans Narrow' => 'PT Sans Narrow',
    'PT Serif' => 'PT Serif',
    'PT Serif Caption' => 'PT Serif Caption',
    'Pacifico' => 'Pacifico',
    'Paprika' => 'Paprika',
    'Parisienne' => 'Parisienne',
    'Passero One' => 'Passero One',
    'Passion One' => 'Passion One',
    'Patrick Hand' => 'Patrick Hand',
    'Patrick Hand SC' => 'Patrick Hand SC',
    'Patua One' => 'Patua One',
    'Paytone One' => 'Paytone One',
    'Peralta' => 'Peralta',
    'Permanent Marker' => 'Permanent Marker',
    'Petit Formal Script' => 'Petit Formal Script',
    'Petrona' => 'Petrona',
    'Philosopher' => 'Philosopher',
    'Piedra' => 'Piedra',
    'Pinyon Script' => 'Pinyon Script',
    'Pirata One' => 'Pirata One',
    'Plaster' => 'Plaster',
    'Palatino Linotype' => 'Palatino Linotype',
    'Play' => 'Play',
    'Playball' => 'Playball',
    'Playfair Display' => 'Playfair Display',
    'Playfair Display SC' => 'Playfair Display SC',
    'Podkova' => 'Podkova',
    'Poiret One' => 'Poiret One',
    'Poller One' => 'Poller One',
    'Poly' => 'Poly',
    'Pompiere' => 'Pompiere',
    'Pontano Sans' => 'Pontano Sans',
    'Port Lligat Sans' => 'Port Lligat Sans',
    'Port Lligat Slab' => 'Port Lligat Slab',
    'Prata' => 'Prata',
    'Pragati Narrow' => 'Pragati Narrow',
    'Preahvihear' => 'Preahvihear',
    'Press Start 2P' => 'Press Start 2P',
    'Princess Sofia' => 'Princess Sofia',
    'Prociono' => 'Prociono',
    'Prosto One' => 'Prosto One',
    'Puritan' => 'Puritan',
    'Purple Purse' => 'Purple Purse',
    'Quando' => 'Quando',
    'Quantico' => 'Quantico',
    'Quattrocento' => 'Quattrocento',
    'Quattrocento Sans' => 'Quattrocento Sans',
    'Questrial' => 'Questrial',
    'Quicksand' => 'Quicksand',
    'Quintessential' => 'Quintessential',
    'Qwigley' => 'Qwigley',
    'Racing Sans One' => 'Racing Sans One',
    'Radley' => 'Radley',
    'Rajdhani' => 'Rajdhani',
    'Raleway Dots' => 'Raleway Dots',
    'Raleway' => 'Raleway',
    'Rambla' => 'Rambla',
    'Ramabhadra' => 'Ramabhadra',
    'Ramaraja' => 'Ramaraja',
    'Rammetto One' => 'Rammetto One',
    'Ranchers' => 'Ranchers',
    'Rancho' => 'Rancho',
    'Ranga' => 'Ranga',
    'Ravi Prakash' => 'Ravi Prakash',
    'Rationale' => 'Rationale',
    'Redressed' => 'Redressed',
    'Reenie Beanie' => 'Reenie Beanie',
    'Revalia' => 'Revalia',
    'Rhodium Libre' => 'Rhodium Libre',
    'Ribeye' => 'Ribeye',
    'Ribeye Marrow' => 'Ribeye Marrow',
    'Righteous' => 'Righteous',
    'Risque' => 'Risque',
    'Roboto' => 'Roboto',
    'Roboto Condensed' => 'Roboto Condensed',
    'Roboto Mono' => 'Roboto Mono',
    'Roboto Slab' => 'Roboto Slab',
    'Rochester' => 'Rochester',
    'Rock Salt' => 'Rock Salt',
    'Rokkitt' => 'Rokkitt',
    'Romanesco' => 'Romanesco',
    'Ropa Sans' => 'Ropa Sans',
    'Rosario' => 'Rosario',
    'Rosarivo' => 'Rosarivo',
    'Rouge Script' => 'Rouge Script',
    'Rozha One' => 'Rozha One',
    'Rubik' => 'Rubik',
    'Rubik One' => 'Rubik One',
    'Rubik Mono One' => 'Rubik Mono One',
    'Ruda' => 'Ruda',
    'Rufina' => 'Rufina',
    'Ruge Boogie' => 'Ruge Boogie',
    'Ruluko' => 'Ruluko',
    'Rum Raisin' => 'Rum Raisin',
    'Ruslan Display' => 'Ruslan Display',
    'Russo One' => 'Russo One',
    'Ruthie' => 'Ruthie',
    'Rye' => 'Rye',
    'Sacramento' => 'Sacramento',
    'Sail' => 'Sail',
    'Salsa' => 'Salsa',
    'Sanchez' => 'Sanchez',
    'Sancreek' => 'Sancreek',
    'Sahitya' => 'Sahitya',
    'Sansita One' => 'Sansita One',
    'Sarpanch' => 'Sarpanch',
    'Sarina' => 'Sarina',
    'Satisfy' => 'Satisfy',
    'Scada' => 'Scada',
    'Scheherazade' => 'Scheherazade',
    'Schoolbell' => 'Schoolbell',
    'Seaweed Script' => 'Seaweed Script',
    'Sarala' => 'Sarala',
    'Sevillana' => 'Sevillana',
    'Seymour One' => 'Seymour One',
    'Shadows Into Light' => 'Shadows Into Light',
    'Shadows Into Light Two' => 'Shadows Into Light Two',
    'Shanti' => 'Shanti',
    'Share' => 'Share',
    'Share Tech' => 'Share Tech',
    'Share Tech Mono' => 'Share Tech Mono',
    'Shojumaru' => 'Shojumaru',
    'Short Stack' => 'Short Stack',
    'Sigmar One' => 'Sigmar One',
    'Suranna' => 'Suranna',
    'Suravaram' => 'Suravaram',
    'Suwannaphum' => 'Suwannaphum',
    'Signika' => 'Signika',
    'Signika Negative' => 'Signika Negative',
    'Simonetta' => 'Simonetta',
    'Siemreap' => 'Siemreap',
    'Sirin Stencil' => 'Sirin Stencil',
    'Six Caps' => 'Six Caps',
    'Skranji' => 'Skranji',
    'Slackey' => 'Slackey',
    'Smokum' => 'Smokum',
    'Smythe' => 'Smythe',
    'Sniglet' => 'Sniglet',
    'Snippet' => 'Snippet',
    'Snowburst One' => 'Snowburst One',
    'Sofadi One' => 'Sofadi One',
    'Sofia' => 'Sofia',
    'Sonsie One' => 'Sonsie One',
    'Sorts Mill Goudy' => 'Sorts Mill Goudy',
    'Sorts Mill Goudy' => 'Sorts Mill Goudy',
    'Source Code Pro' => 'Source Code Pro',
    'Source Sans Pro' => 'Source Sans Pro',
    'Special I am one' => 'Special I am one',
    'Spicy Rice' => 'Spicy Rice',
    'Spinnaker' => 'Spinnaker',
    'Spirax' => 'Spirax',
    'Squada One' => 'Squada One',
    'Sree Krushnadevaraya' => 'Sree Krushnadevaraya',
    'Stalemate' => 'Stalemate',
    'Stalinist One' => 'Stalinist One',
    'Stardos Stencil' => 'Stardos Stencil',
    'Stint Ultra Condensed' => 'Stint Ultra Condensed',
    'Stint Ultra Expanded' => 'Stint Ultra Expanded',
    'Stoke' => 'Stoke',
    'Stoke' => 'Stoke',
    'Strait' => 'Strait',
    'Sura' => 'Sura',
    'Sumana' => 'Sumana',
    'Sue Ellen Francisco' => 'Sue Ellen Francisco',
    'Sunshiney' => 'Sunshiney',
    'Supermercado One' => 'Supermercado One',
    'Swanky and Moo Moo' => 'Swanky and Moo Moo',
    'Syncopate' => 'Syncopate',
    'Symbol' => 'Symbol',
    'Timmana' => 'Timmana',
    'Taprom' => 'Taprom',
    'Tangerine' => 'Tangerine',
    'Tahoma' => 'Tahoma',
    'Teko' => 'Teko',
    'Telex' => 'Telex',
    'Tenali Ramakrishna' => 'Tenali Ramakrishna',
    'Tenor Sans' => 'Tenor Sans',
    'Terminal Dosis' => 'Terminal Dosis',
    'Terminal Dosis Light' => 'Terminal Dosis Light',
    'Text Me One' => 'Text Me One',
    'The Girl Next Door' => 'The Girl Next Door',
    'Tienne' => 'Tienne',
    'Tillana' => 'Tillana',
    'Tinos' => 'Tinos',
    'Titan One' => 'Titan One',
    'Titillium Web' => 'Titillium Web',
    'Trade Winds' => 'Trade Winds',
    'Trebuchet MS' => 'Trebuchet MS',
    'Trocchi' => 'Trocchi',
    'Trochut' => 'Trochut',
    'Trykker' => 'Trykker',
    'Tulpen One' => 'Tulpen One',
    'Ubuntu' => 'Ubuntu',
    'Ubuntu Condensed' => 'Ubuntu Condensed',
    'Ubuntu Mono' => 'Ubuntu Mono',
    'Ultra' => 'Ultra',
    'Uncial Antiqua' => 'Uncial Antiqua',
    'Underdog' => 'Underdog',
    'Unica One' => 'Unica One',
    'UnifrakturCook' => 'UnifrakturCook',
    'UnifrakturMaguntia' => 'UnifrakturMaguntia',
    'Unkempt' => 'Unkempt',
    'Unlock' => 'Unlock',
    'Unna' => 'Unna',
    'VT323' => 'VT323',
    'Vampiro One' => 'Vampiro One',
    'Varela' => 'Varela',
    'Varela Round' => 'Varela Round',
    'Vast Shadow' => 'Vast Shadow',
    'Vesper Libre' => 'Vesper Libre',
    'Verdana' => 'Verdana',
    'Vibur' => 'Vibur',
    'Vidaloka' => 'Vidaloka',
    'Viga' => 'Viga',
    'Voces' => 'Voces',
    'Volkhov' => 'Volkhov',
    'Vollkorn' => 'Vollkorn',
    'Voltaire' => 'Voltaire',
    'Waiting for the Sunrise' => 'Waiting for the Sunrise',
    'Wallpoet' => 'Wallpoet',
    'Walter Turncoat' => 'Walter Turncoat',
    'Warnes' => 'Warnes',
    'Wellfleet' => 'Wellfleet',
    'Wendy One' => 'Wendy One',
    'Wire One' => 'Wire One',
    'Yanone Kaffeesatz' => 'Yanone Kaffeesatz',
    'Yantramanav' => 'Yantramanav',
    'Yellowtail' => 'Yellowtail',
    'Yeseva One' => 'Yeseva One',
    'Yesteryear' => 'Yesteryear',
    'Zeyada' => 'Zeyada'
  );

	//array of all font sizes.
	$font_sizes = array( 
		'10px' => '10px',
		'11px' => '11px',
	);
	
	$options = array();
	$imagepath =  get_template_directory_uri() . '/images/';

	
	for($n=12;$n<=200;$n+=1){
		$font_sizes[$n.'px'] = $n.'px';
	}
	
	// Pull all the pages into an array
	 $options_pages = array();
	 $options_pages_obj = get_pages('sort_column=post_parent,menu_order');
	 $options_pages[''] = 'Select a page:';
	 foreach ($options_pages_obj as $page) {
	  $options_pages[$page->ID] = $page->post_title;
	 }

	// array of section content.
	$section_text = array(
	
		 1 => array(
			'section_title'	=> 'About Us',
			'menutitle'		=> '',
			'bgcolor' 		=> '#f6f6f5',
			'bgimage'		=> '',
			'class'			=> 'two-column',
			'content'		=> '<div class="column-thumb"><img src="'.get_template_directory_uri().'/images/twocol-img.jpg"></div><div class="column-content"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam non vulputate risus, nec dignissim ex. Mauris feugiat nisl ex. Vivamus ornare, diam a efficitur dignissim, enim arcu faucibus ipsum, eget convallis lorem sem id neque. In eu condimentum dolor. Duis ultrices dolor sit amet nibh semper gravida. Aliquam sem velit, mattis eu venenatis non, pellentesque ac velit. Mauris placerat nisi vitae nunc condimentum, id pretium nisi faucibus. Curabitur sed risus ante. Vestibulum nec imperdiet eros, vitae mattis velit.</p><p>Nulla consectetur laoreet purus, nec condimentum nisl consequat quis. Donec varius convallis mi, at condimentum dolor convallis sit amet. Aliquam porta nisi sed dictum posuere. In imperdiet eros et justo viverra elementum. Aenean vitae convallis enim. Morbi interdum accumsan ex vitae rutrum. Nunc accumsan justo eget ante sodales cursus. Phasellus finibus metus non metus lobortis rhoncus. Vestibulum sit amet pellentesque ipsum.</p><div class="clear"></div><a class="buttonstyle1" href="#">Read More</a></div><div class="clear"></div>',
		 ),	
		 
		 2 => array(
			'section_title'	=> 'Recent Work',
			'menutitle'		=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[recentwork show="3"]',
		),	
		
		
		3 => array(
			'section_title'	=> '',
			'menutitle'		=> '',
			'bgcolor' 		=> '#f6f6f5',
			'bgimage'		=> '',
			'class'			=> 'whyus',
			'content'		=> '[whyus image="'.get_template_directory_uri().'/images/whyus.png" title="Why Us" link="#"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.[/whyus][whyus image="'.get_template_directory_uri().'/images/mission.png" title="Mission" link="#"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.[/whyus][whyus image="'.get_template_directory_uri().'/images/values.png" title="Our Values" link="#" last="yes"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.[/whyus]'
		),
		
		4 => array(
			'section_title'	=> 'You Don&rsquo;t Need A Contractor To Make Over Your Walls',
			'menutitle'		=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> get_template_directory_uri().'/images/quote.jpg',
			'class'			=> 'getquote',
			'content'		=> 'Aliquam finibus felis eget ipsum finibus, ut pulvinar sem interdum. Suspendisse vitae ex tempus, lobortis leo a, rutrum ligula. Integer ut ligula pretium, faucibus arcu non, dignissim ex. Sed facilisis sem urna<div class="clear"></div><a href="#" class="morebutton">Get A Quote Now</a>'
		),		
		
		
		5 => array(
			'section_title'	=> 'Latest From The Blog',
			'menutitle'		=> '',
			'bgcolor' 		=> '#f6f6f5',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[latest-news showposts="3" comment="show" date="show" author="show"]'
		),
		
		6 => array(
			'section_title'	=> 'What Client&rsquo;s Say About Us',
			'menutitle'		=> '',
			'bgcolor' 		=> '',
			'bgimage'		=> '',
			'class'			=> '',
			'content'		=> '[testimonials]'
		),
		
		7 => array(
			'section_title'	=> 'Our Clients',
			'menutitle'		=> '',
			'bgcolor' 		=> '#f6f6f5',
			'bgimage'		=> '',
			'class'			=> 'clientwrap',
			'content'		=> '[client_lists][client image="'.get_template_directory_uri().'/images/logo1.jpg" link="#"][client image="'.get_template_directory_uri().'/images/logo2.jpg" link="#"][client image="'.get_template_directory_uri().'/images/logo3.jpg" link="#"][client image="'.get_template_directory_uri().'/images/logo4.jpg" link="#"][client image="'.get_template_directory_uri().'/images/logo5.jpg" link="#"][/client_lists]',
		),						

	);

	$options = array();

	//Basic Settings
	$options[] = array(
		'name' => __('Basic Settings', 'decorator'),
		'type' => 'heading');

	$options[] = array(
		'name' => __('Logo', 'decorator'),
		'desc' => __('Upload your main logo here', 'decorator'),
		'id' => 'logo',
		'class' => '',
		'std'	=> 'Decorator',
		'type' => 'upload');
		
	$options[] = array(		
		'desc' => __('Change your custom logo height', 'decorator'),
		'id' => 'logoheight',
		'std' => '48',
		'type' => 'text');
		
	$options[] = array(			
			'desc'	=> __('Check To View Box Layout ', 'decorator'),
			'id'	=> 'boxlayout',
			'type'	=> 'checkbox',
			'std'	=> '');

	$options[] = array(
		'name' => __('Custom CSS', 'decorator'),
		'desc' => __('Some Custom Styling for your site. Place any css codes here instead of the style.css file.', 'decorator'),
		'id' => 'style2',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Header Top Social Icons', 'decorator'),
		'desc' => __('Edit select social icons for header top', 'decorator'),
		'id' => 'headersocial',
		'std' => ' [social_area] [social icon="facebook" link="#"] [social icon="twitter" link="#"] [social icon="google-plus" link="#"] [social icon="linkedin" link="#"][/social_area]',
		'type' => 'textarea');	
		
	$options[] = array(
		'name' => __('Header Top Info', 'decorator'),
		'desc' => __('Edit header info from here. NOTE: Icon name should be in lowercase without space.(exa.phone) More social icons can be found at: http://fortawesome.github.io/Font-Awesome/icons/', 'decorator'),
		'id' => 'headerinfo',
		'std' => '<i class="fa fa-phone"></i> +01 23 456 7890 <span class="phno"><a href="mailto:info@sitename.com"><i class="fa fa-envelope"></i>info@sitename.com</a></span>',
		'type' => 'textarea');		
			
		
	// font family start 		
	$options[] = array(
		'name' => __('Font Faces', 'decorator'),
		'desc' => __('Select font for the body text', 'decorator'),
		'id' => 'bodyfontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );
		
	$options[] = array(
		'desc' => __('Select font for the textual logo', 'decorator'),
		'id' => 'logofontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );
		
	$options[] = array(
		'desc' => __('Select font for the navigation text', 'decorator'),
		'id' => 'navfontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );
		
	$options[] = array(
		'desc' => __('Select font family for all heading tag.', 'decorator'),
		'id' => 'headfontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );
		
	$options[] = array(
		'desc' => __('Select font for Slide title', 'decorator'),
		'id' => 'slidetitlefontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );
		
	$options[] = array(
		'desc' => __('Select font for Slide small title', 'decorator'),
		'id' => 'slidesmtitlefontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );	
		
	$options[] = array(
		'desc' => __('Select font for Slide Description', 'decorator'),
		'id' => 'slidedesfontface',
		'type' => 'select',
		'std' => 'Montserrat',
		'options' => $font_types );	

		
	// font sizes start	
	$options[] = array(
		'name' => __('Font Sizes', 'decorator'),
		'desc' => __('Select font size for body text', 'decorator'),
		'id' => 'bodyfontsize',
		'type' => 'select',
		'std' => '13px',
		'options' => $font_sizes );
		
	$options[] = array(
		'desc' => __('Select font size for textual logo', 'decorator'),
		'id' => 'logofontsize',
		'type' => 'select',
		'std' => '30px',
		'options' => $font_sizes );
		
	$options[] = array(
		'desc' => __('Select font size for navigation', 'decorator'),
		'id' => 'navfontsize',
		'type' => 'select',
		'std' => '15px',
		'options' => $font_sizes );	
		
	$options[] = array(
		'desc' => __('Select font size for section title', 'decorator'),
		'id' => 'sectitlesize',
		'type' => 'select',
		'std' => '30px',
		'options' => $font_sizes );
		
	$options[] = array(
		'desc' => __('Select font size for footer title', 'decorator'),
		'id' => 'ftfontsize',
		'type' => 'select',
		'std' => '20px',
		'options' => $font_sizes );	

	$options[] = array(
		'desc' => __('Select h1 font size', 'decorator'),
		'id' => 'h1fontsize',
		'std' => '35px',
		'type' => 'select',
		'options' => $font_sizes);

	$options[] = array(
		'desc' => __('Select h2 font size', 'decorator'),
		'id' => 'h2fontsize',
		'std' => '25px',
		'type' => 'select',
		'options' => $font_sizes);

	$options[] = array(
		'desc' => __('Select h3 font size', 'decorator'),
		'id' => 'h3fontsize',
		'std' => '20px',
		'type' => 'select',
		'options' => $font_sizes);

	$options[] = array(
		'desc' => __('Select h4 font size', 'decorator'),
		'id' => 'h4fontsize',
		'std' => '16px',
		'type' => 'select',
		'options' => $font_sizes);

	$options[] = array(
		'desc' => __('Select h5 font size', 'decorator'),
		'id' => 'h5fontsize',
		'std' => '15px',
		'type' => 'select',
		'options' => $font_sizes);

	$options[] = array(
		'desc' => __('Select h6 font size', 'decorator'),
		'id' => 'h6fontsize',
		'std' => '14px',
		'type' => 'select',
		'options' => $font_sizes);


	// font colors start
	
	$options[] = array(
		'name' => __('Font Colors', 'decorator'),
		'desc' => __('Select h1 font color', 'decorator'),
		'id' => 'h1fontcolor',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select h2 font color', 'decorator'),
		'id' => 'h2fontcolor',
		'std' => '#362b21',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select h3 font color', 'decorator'),
		'id' => 'h3fontcolor',
		'std' => '#362b21',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select h4 font color', 'decorator'),
		'id' => 'h4fontcolor',
		'std' => '#362b21',
		'type' => 'color');	

	$options[] = array(
		'desc' => __('Select h5 font color', 'decorator'),
		'id' => 'h5fontcolor',
		'std' => '#362b21',
		'type' => 'color');	

	$options[] = array(
		'desc' => __('Select h6 font color', 'decorator'),
		'id' => 'h6fontcolor',
		'std' => '#362b21',
		'type' => 'color');

	$options[] = array(		
		'desc' => __('Select font color for the body text', 'decorator'),
		'id' => 'bodyfontcolor',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for textual logo', 'decorator'),
		'id' => 'logofontcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for logo tagline', 'decorator'),
		'id' => 'logotaglinecolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for header top', 'decorator'),
		'id' => 'headertopcolor',
		'std' => '#e0ccba',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for header top left icon', 'decorator'),
		'id' => 'headertoplefticoncolor',
		'std' => '#ffffff',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font color for social icons', 'decorator'),
		'id' => 'socialfontcolor',
		'std' => '#e0ccba',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font hover color for social icons', 'decorator'),
		'id' => 'socialfonthvcolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for section title', 'decorator'),
		'id' => 'sectitlecolor',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for get a quote section title', 'decorator'),
		'id' => 'getquotesectitlecolor',
		'std' => '#ffffff',
		'type' => 'color');			
	
	$options[] = array(
		'desc' => __('Select font color for navigation', 'decorator'),
		'id' => 'navfontcolor',
		'std' => '#ffffff',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font color for navigation hover', 'decorator'),
		'id' => 'navhovercolor',
		'std' => '#1c1006',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for homepage top three boxes', 'decorator'),
		'id' => 'hometopfourbxcolor',
		'std' => '#fdf5ec',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for homepage top three boxes title', 'decorator'),
		'id' => 'hometopfourbxtitlecolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for recent work three boxes hover title', 'decorator'),
		'id' => 'recentbxhvtitlecolor',
		'std' => '#3d2c1d',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for client testimonilas title', 'decorator'),
		'id' => 'testimonialtitlecolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for client testimonilas description', 'decorator'),
		'id' => 'testimonialdesccolor',
		'std' => '#33281e',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for client testimonilas company name', 'decorator'),
		'id' => 'testimonialtitlecomp',
		'std' => '#33281e',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for latest post title', 'decorator'),
		'id' => 'latestpoststtlcolor',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for news post meta', 'decorator'),
		'id' => 'postmeta',
		'std' => '#9d9d9d',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer title', 'decorator'),
		'id' => 'foottitlecolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer', 'decorator'),
		'id' => 'footdesccolor',
		'std' => '#b38f6e',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font hover color for footer link ', 'decorator'),
		'id' => 'footermenucolor',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for footer left text (copyright)', 'decorator'),
		'id' => 'copycolor',
		'std' => '#ffffff',
		'type' => 'color');	

	$options[] = array(
		'desc' => __('Select font color for links / anchor tags', 'decorator'),
		'id' => 'linkcolor',
		'std' => '#362b21',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font hover color for links / anchor tags', 'decorator'),
		'id' => 'linkhovercolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer top contact icon', 'decorator'),
		'id' => 'footconiconfontcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer social icon', 'decorator'),
		'id' => 'footsocialfontcolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font hover color for footer social icon', 'decorator'),
		'id' => 'footsocialfontcolorhv',
		'std' => '#ffffff',
		'type' => 'color');			
		
	$options[] = array(
		'desc' => __('Select font color for sidebar li a', 'decorator'),
		'id' => 'sidebarfontcolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font hover color for sidebar li a', 'decorator'),
		'id' => 'sidebarfonthvcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for footer copyright links', 'decorator'),
		'id' => 'copylinks',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for widget title', 'decorator'),
		'id' => 'wdgttitleccolor',
		'std' => '#e4e3e3',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for sidebar widget box', 'decorator'),
		'id' => 'widgetboxfontcolor',
		'std' => '#b38f6e',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select font color for toggle menu on responsive', 'decorator'),
		'id' => 'togglemenucolor',
		'std' => '#ffffff',
		'type' => 'color');										
					
		
	// Background start			
	$options[] = array(
		'name' => __('Background Colors', 'decorator'),				
		'desc' => __('Select background color for body', 'decorator'),
		'id' => 'bodybgcolor',
		'std' => '#ffffff',
		'type' => 'color');
	
	$options[] = array(	
		'desc' => __('Select background color for header top', 'decorator'),
		'id' => 'headertopbgcolor',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(	
		'desc' => __('Select background color for header contact page', 'decorator'),
		'id' => 'headconpagebgcolor',
		'std' => '#251d15',
		'type' => 'color');
		
	$options[] = array(	
		'desc' => __('Select background hover color for header top social icon', 'decorator'),
		'id' => 'headertopiconhvbgcolor',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(			
		'desc' => __('Select background color for header', 'decorator'),
		'id' => 'headbgcolor',
		'std' => '#000000',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background opacity for header', 'decorator'),
		'id' => 'headbgopacity',
		'std' => '0.3',
		'type' => 'select',
		'options' => array('0.9' => 0.9, '0.8' => 0.8, '0.7' => 0.7, '0.6' => 0.6, '0.5' => 0.5, '0.4' => 0.4, '0.3' => 0.3, '0.2' => 0.2, '1' => 1));	
		
	$options[] = array(
		'desc' => __('Select background color for header nav dropdown', 'decorator'),
		'id' => 'navdpbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background color for toggle menu', 'decorator'),
		'id' => 'togglemenu',
		'std' => '#362b21',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background border hover color for homepage top three boxes', 'decorator'),
		'id' => 'hometopfourbxbdrcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select background hover color for recent work three box', 'decorator'),
		'id' => 'recentbxhvbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover opacity for recent work three box', 'decorator'),
		'id' => 'recentbxhvbgopacity',
		'std' => '0.9',
		'type' => 'select',
		'options' => array('0.9' => 0.9, '0.8' => 0.8, '0.7' => 0.7, '0.6' => 0.6, '0.5' => 0.5, '0.4' => 0.4, '0.3' => 0.3, '0.2' => 0.2, '1' => 1));
		
	$options[] = array(			
		'desc' => __('Select background color for recent work three box view button', 'decorator'),
		'id' => 'recentbxviewbtnbgcolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background color for client testimonials pager dots', 'decorator'),
		'id' => 'testidotsbgcolor',
		'std' => '#33281e',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background active color for client testimonials pager dots', 'decorator'),
		'id' => 'testidotsbgcolorhv',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background color for footer top contact', 'decorator'),
		'id' => 'footertopbgcolor',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background color for footer', 'decorator'),
		'id' => 'footerbgcolor',
		'std' => '#33281e',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background color for footer social icon', 'decorator'),
		'id' => 'footersociconbgcolor',
		'std' => '#574535',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover color for footer social icon', 'decorator'),
		'id' => 'footersociconhvbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background color for copyright section', 'decorator'),
		'id' => 'copybgcolor',
		'std' => '#251d15',
		'type' => 'color');	
	
	$options[] = array(
		'desc' => __('Select background color for sidebar widget box', 'decorator'),
		'id' => 'widgetboxbgcolor',
		'std' => '#33281e',
		'type' => 'color');	
	
	$options[] = array(
		'desc' => __('Select background color for sidebar widget title', 'decorator'),
		'id' => 'widgettitlebgcolor',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background color for our skill bar', 'decorator'),
		'id' => 'skillbarbgcolor',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background active color for our skill bar', 'decorator'),
		'id' => 'skillbarbgcoloractive',
		'std' => '#ffae00',
		'type' => 'color');					

	// Border colors
	$options[] = array(
		'name' => __('Border Colors', 'decorator'),	
		'desc' => __('Select border color for sidebar li a', 'decorator'),
		'id' => 'sidebarliaborder',
		'std' => '#251d15',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border color for header top social icon', 'decorator'),
		'id' => 'headtopiconborder',
		'std' => '#453d2d',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border color for client logo image', 'decorator'),
		'id' => 'clientlogoimageborder',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border color for footer top contact icon', 'decorator'),
		'id' => 'footerconiconborder',
		'std' => '#33281e',
		'type' => 'color');			
		
	$options[] = array(			
		'desc' => __('Select border color for footer latest post', 'decorator'),
		'id' => 'footerpostborder',
		'std' => '#4d3d2e',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border color for footer recent work image box', 'decorator'),
		'id' => 'footrecentimgbxborder',
		'std' => '#8a7059',
		'type' => 'color');	
		
		
	// Default Buttons		
	$options[] = array(
		'name' => __('Button Colors', 'decorator'),		
		'desc' => __('Select background color for default button', 'decorator'),
		'id' => 'btnbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover color for default button', 'decorator'),
		'id' => 'btnbghvcolor',
		'std' => '#392e24',
		'type' => 'color');		

	$options[] = array(
		'desc' => __('Select font color default button', 'decorator'),
		'id' => 'btntxtcolor',
		'std' => '#392e24',
		'type' => 'color');

	$options[] = array(
		'desc' => __('Select font hover color for default button', 'decorator'),
		'id' => 'btntxthvcolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border color for home page all read more button', 'decorator'),
		'id' => 'readmorebuttonborder',
		'std' => '#42433d',
		'type' => 'color');
		
	$options[] = array(			
		'desc' => __('Select border hover color for home page all read more button', 'decorator'),
		'id' => 'readmorebuttonhvborder',
		'std' => '#ffae00',
		'type' => 'color');
		
	// Portfolio Gallery
	$options[] = array(
		'name' => __('Portfolio Colors/Background', 'decorator'),
		'desc' => __('Select background color for portfolio image hover', 'decorator'),
		'id' => 'holdwrapbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background color for portfolio filter tab selected', 'decorator'),
		'id' => 'filtertabselectedbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background hover color for portfolio filter tab', 'decorator'),
		'id' => 'filtertabhvbgcolor',
		'std' => '#ffae00',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select font color for portfolio filter tab', 'decorator'),
		'id' => 'filtertabfontcolor',
		'std' => '#362b21',
		'type' => 'color');
		
	// Tab and Accordian colors
	$options[] = array(	
		'name' => __('Tab And Toggle Colors', 'decorator'),				
		'desc' => __('Select background color for tab button', 'decorator'),
		'id' => 'tabbgcolor',
		'std' => '#362b21',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select background hover/active color for tab button', 'decorator'),
		'id' => 'tabbgcolorhv',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font color for tab button', 'decorator'),
		'id' => 'tabfontcolor',
		'std' => '#33281e',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font hover/active color for tab button', 'decorator'),
		'id' => 'tabfontcolorhv',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select border color for tab content', 'decorator'),
		'id' => 'tabcontentborder',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font color for tab description', 'decorator'),
		'id' => 'tabcontentfontcolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font color for accordion title', 'decorator'),
		'id' => 'acctitlecolor',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select border color for accordion title', 'decorator'),
		'id' => 'acctitlebordercolor',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select background active color for accordion title', 'decorator'),
		'id' => 'acctitlebgcolorhv',
		'std' => '#251d15',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font active color for accordion title', 'decorator'),
		'id' => 'acctitlecolorhv',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select background color for accordion description box', 'decorator'),
		'id' => 'accdescbgcolor',
		'std' => '#33281e',
		'type' => 'color');	
		
	$options[] = array(					
		'desc' => __('Select font color for accordion description box', 'decorator'),
		'id' => 'accdescfontcolor',
		'std' => '#b38f6e',
		'type' => 'color');	
		
		
	// Slider Caption colors
	$options[] = array(	
		'name' => __('Select font color/size/fontface for Slider Caption', 'decorator'),
		'desc' => __('Select font color for slider title', 'decorator'),
		'id' => 'slidetitlecolor',
		'std' => '#ffffff',
		'type' => 'color');
		
	$options[] = array(		
		'desc' => __('Select font color for slider small title', 'decorator'),
		'id' => 'slidesmtitlecolor',
		'std' => '#ffffff',
		'type' => 'color');			
		
	$options[] = array(		
		'desc' => __('Select font color for slider description', 'decorator'),
		'id' => 'slidedesccolor',
		'std' => '#ffffff',
		'type' => 'color');		
		
	$options[] = array(
		'desc' => __('Select font size for slider title', 'decorator'),
		'id' => 'slidetitlefontsize',
		'type' => 'select',
		'std' => '43px',
		'options' => $font_sizes );
		
	$options[] = array(
		'desc' => __('Select font size for slider small title', 'decorator'),
		'id' => 'slidesmtitlefontsize',
		'type' => 'select',
		'std' => '16px',
		'options' => $font_sizes );
		
	$options[] = array(
		'desc' => __('Select font size for slider description', 'decorator'),
		'id' => 'slidedescfontsize',
		'type' => 'select',
		'std' => '16px',
		'options' => $font_sizes );
		
	// Slider controls colors		
	$options[] = array(
		'name' => __('Slider controls Colors', 'decorator'),
		'desc' => __('Select background color for slider pager', 'decorator'),
		'id' => 'sldpagebg',
		'std' => '#251d15',
		'type' => 'color');
		
	$options[] = array(
		'desc' => __('Select background active color for slider pager', 'decorator'),
		'id' => 'sldpagehvbg',
		'std' => '#ffae00',
		'type' => 'color');	
		
	$options[] = array(
		'desc' => __('Select background color for slider navigation arrows', 'decorator'),
		'id' => 'sldarrowbg',
		'std' => '#000000',
		'type' => 'color');	
		
	$options[] = array(		
		'desc' => __('Select background opacity color for header slider navigation arrows', 'decorator'),
		'id' => 'sldarrowopacity',
		'std' => '0.7',
		'type' => 'select',
		'options'	=> array('1'=>1, '0.9'=>0.9,'0.8'=>0.8,'0.7'=>0.7,'0.6'=>0.6,'0.5'=>0.5,'0.4'=>0.4,'0.3'=>0.3,'0.2'=>0.2,));			
		
	$options[] = array(
		'desc' => __('Select Border color for slider pager', 'decorator'),
		'id' => 'sldpagehvbd',
		'std' => '#ffffff',
		'type' => 'color');	
		
	$options[] = array(	
		'name' => __('Excerpt Lenth', 'decorator'),		
		'desc' => __('Select excerpt length for latest blog boxes section', 'decorator'),
		'id' => 'latestnewslength',
		'std' => '28',
		'type' => 'text');
		
	$options[] = array(	
		'desc' => __('Select excerpt length for recent work boxes section', 'decorator'),
		'id' => 'workexcerptlength',
		'std' => '60',
		'type' => 'text');
		
	$options[] = array(		
		'desc' => __('Select excerpt length for team section', 'decorator'),
		'id' => 'teamexcerptlength',
		'std' => '16',
		'type' => 'text');	
		
	$options[] = array(		
		'desc' => __('Select excerpt length for testimonials section', 'decorator'),
		'id' => 'testimonialsexcerptlength',
		'std' => '60',
		'type' => 'text');
		
	$options[] = array(		
		'desc' => __('Select excerpt length for blog post', 'decorator'),
		'id' => 'blogpostexcerptlength',
		'std' => '60',
		'type' => 'text');
		
	$options[] = array(		
		'desc' => __('Select excerpt length for footer latest posts', 'decorator'),
		'id' => 'footerpostslength',
		'std' => '10',
		'type' => 'text');
		
	$options[] = array(	
		'name' => __('Read More Text', 'decorator'),		
		'desc' => __('Change read more button text for blog posts ', 'decorator'),
		'id' => 'blogpostreadmoretext',
		'std' => 'Read More',
		'type' => 'text');		
		
	$options[] = array(
		'name' => __('Responsive View Menu word Changeable', 'decorator'),
		'desc' => __('Change menu word on responsive view', 'decorator'),
		'id' => 'menuwordchange',
		'std' => 'Menu',
		'type' => 'text');			
		
	$options[] = array(
		'name' => __('Blog Single Layout', 'decorator'),
		'desc' => __('Select layout. eg:Boxed, Wide', 'decorator'),
		'id' => 'singlelayout',
		'type' => 'select',
		'std' => 'singleright',
		'options' => array('singleright'=>'Blog Single Right Sidebar', 'singleleft'=>'Blog Single Left Sidebar', 'sitefull'=>'Blog Single Full Width', 'nosidebar'=>'Blog Single No Sidebar') );	
		
	$options[] = array(
		'name' => __('Woocommerce Page Layout', 'decorator'),
		'desc' => __('Select layout. eg:right-sidebar, left-sidebar, full-width', 'decorator'),
		'id' => 'woocommercelayout',
		'type' => 'select',
		'std' => 'woocommercesitefull',
		'options' => array('woocommerceright'=>'Woocommerce Right Sidebar', 'woocommerceleft'=>'Woocommerce Left Sidebar', 'woocommercesitefull'=>'Woocommerce Full Width') );		
		

	//Layout Settings
	$options[] = array(
		'name' => __('Sections', 'decorator'),
		'type' => 'heading');
		
	$options[] = array(	
		'desc'	=> __('first Features box for frontpage section','decorator'),
		'id' 	=> 'box1',
		'type'	=> 'select',
		'options' => $options_pages,);
	
	$options[] = array(		
		'desc' => __('upload image for first box.', 'decorator'),
		'id' => 'boximg1',
		'class' => '',
		'std'	=> get_template_directory_uri().'/images/feature1.jpg',
		'type' => 'upload');	
		
	$options[] = array(		
		'desc' => __('Select background color for first box.', 'decorator'),
		'id' => 'boxbg1',
		'class' => '',
		'std'	=> '#362b21',
		'type' => 'color');	
	
	$options[] = array(	
		'desc' => __('Change read more button text for top features three boxes ', 'decorator'),
		'id' => 'readmorebutton',
		'std' => 'More Info',
		'type' => 'text');
		
	$options[] = array(	
		'desc'	=> __('Second Features box for frontpage section','decorator'),
		'id' 	=> 'box2',
		'type'	=> 'select',
		'options' => $options_pages,
	);
	
	$options[] = array(		
		'desc' => __('upload image for second box.', 'decorator'),
		'id' => 'boximg2',
		'class' => '',
		'std'	=> get_template_directory_uri().'/images/feature2.jpg',
		'type' => 'upload');
		
	$options[] = array(		
		'desc' => __('Select background color for second box.', 'decorator'),
		'id' => 'boxbg2',
		'class' => '',
		'std'	=> '#362b21',
		'type' => 'color');	
		
	$options[] = array(	
		'desc' => __('Change read more button text for top features three boxes ', 'decorator'),
		'id' => 'readmorebutton',
		'std' => 'More Info',
		'type' => 'text');
		
	
	$options[] = array(	
		'desc'	=> __('Third Features box for frontpage section','decorator'),
		'id' 	=> 'box3',
		'type'	=> 'select',
		'options' => $options_pages,
	);
	
	$options[] = array(		
		'desc' => __('upload image for third box.', 'decorator'),
		'id' => 'boximg3',
		'class' => '',
		'std'	=> get_template_directory_uri().'/images/feature3.jpg',
		'type' => 'upload');
		
	$options[] = array(		
		'desc' => __('Select background color for third box.', 'decorator'),
		'id' => 'boxbg3',
		'class' => '',
		'std'	=> '#362b21',
		'type' => 'color');
		
	$options[] = array(	
		'desc' => __('Change read more button text for  top features three boxes ', 'decorator'),
		'id' => 'readmorebutton',
		'std' => 'More Info',
		'type' => 'text');
		
			
	$options[] = array(	
		'desc'	=> __('Fourth Features box for frontpage section','decorator'),
		'id' 	=> 'box4',
		'type'	=> 'select',
		'options' => $options_pages,
	);
	
	$options[] = array(		
		'desc' => __('upload image for fourth box.', 'decorator'),
		'id' => 'boximg4',
		'class' => '',
		'std'	=> '',
		'type' => 'upload');
		
	$options[] = array(		
		'desc' => __('Select background color for fourth box.', 'decorator'),
		'id' => 'boxbg4',
		'class' => '',
		'std'	=> '#362b21',
		'type' => 'color');
		
	$options[] = array(	
		'desc' => __('Change read more button text for top features fourth boxes ', 'decorator'),
		'id' => 'readmorebutton',
		'std' => 'More Info',
		'type' => 'text');
		
		
	$options[] = array(	
		'desc'	=> __('Fifth Features box for frontpage section','decorator'),
		'id' 	=> 'box5',
		'type'	=> 'select',
		'options' => $options_pages,
	);
	
	$options[] = array(		
		'desc' => __('upload image for fifth box.', 'decorator'),
		'id' => 'boximg5',
		'class' => '',
		'std'	=> '',
		'type' => 'upload');
		
	$options[] = array(		
		'desc' => __('Select background color for fifth box.', 'decorator'),
		'id' => 'boxbg5',
		'class' => '',
		'std'	=> '#362b21',
		'type' => 'color');
		
	$options[] = array(	
		'desc' => __('Change read more button text for  top features fifth boxes ', 'decorator'),
		'id' => 'readmorebutton',
		'std' => 'More Info',
		'type' => 'text');	
	
		
	$options[] = array(		
		'desc' => __('Select excerpt length for features three boxes section', 'decorator'),
		'id' => 'pageboxlength',
		'std' => '20',
		'type' => 'text');			
	
	$options[] = array(			
			'desc'	=> __('Check to hide above our features three column section', 'decorator'),
			'id'	=> 'hidefourbxsec',
			'type'	=> 'checkbox',
			'std'	=> '');
	
	$options[] = array(
		'name' => __('Number of Sections', 'decorator'),
		'desc' => __('Select number of sections', 'decorator'),
		'id' => 'numsection',
		'type' => 'select',
		'std' => '7',
		'options' => array_combine(range(1,30), range(1,30)) );

	$numsecs = of_get_option( 'numsection', 7 );

	for( $n=1; $n<=$numsecs; $n++){
		$options[] = array(
			'desc' => __("<h3>Section ".$n."</h3>", 'decorator'),
			'class' => 'toggle_title',
			'type' => 'info');	
	
		$options[] = array(
			'name' => __('Section Title', 'decorator'),
			'id' => 'sectiontitle'.$n,
			'std' => ( ( isset($section_text[$n]['section_title']) ) ? $section_text[$n]['section_title'] : '' ),
			'type' => 'text');

		$options[] = array(
			'name' => __('Section ID', 'decorator'),
			'desc'	=> __('Enter your section ID here. SECTION ID MUST BE IN SMALL LETTERS ONLY AND DO NOT ADD SPACE OR SYMBOL.', 'decorator'),
			'id' => 'menutitle'.$n,
			'std' => ( ( isset($section_text[$n]['menutitle']) ) ? $section_text[$n]['menutitle'] : '' ),
			'type' => 'text');

		$options[] = array(
			'name' => __('Section Background Color', 'decorator'),
			'desc' => __('Select background color for section', 'decorator'),
			'id' => 'sectionbgcolor'.$n,
			'std' => ( ( isset($section_text[$n]['bgcolor']) ) ? $section_text[$n]['bgcolor'] : '' ),
			'type' => 'color');
			
		$options[] = array(
			'name' => __('Background Image', 'decorator'),
			'id' => 'sectionbgimage'.$n,
			'class' => '',
			'std' => ( ( isset($section_text[$n]['bgimage']) ) ? $section_text[$n]['bgimage'] : '' ),
			'type' => 'upload');

		$options[] = array(
			'name' => __('Section CSS Class', 'decorator'),
			'desc' => __('Set class for this section.', 'decorator'),
			'id' => 'sectionclass'.$n,
			'std' => ( ( isset($section_text[$n]['class']) ) ? $section_text[$n]['class'] : '' ),
			'type' => 'text');
			
		$options[] = array(
			'name'	=> __('Hide Section', 'decorator'),
			'desc'	=> __('Check to hide this section', 'decorator'),
			'id'	=> 'hidesec'.$n,
			'type'	=> 'checkbox',
			'std'	=> '');

		$options[] = array(
			'name' => __('Section Content', 'decorator'),
			'id' => 'sectioncontent'.$n,
			'std' => ( ( isset($section_text[$n]['content']) ) ? $section_text[$n]['content'] : '' ),
			'type' => 'editor');
	}


	//SLIDER SETTINGS
	$options[] = array(
		'name' => __('Homepage Slider', 'decorator'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('Inner Page Banner', 'decorator'),
		'desc' => __('Upload inner page banner for site', 'decorator'),
		'id' => 'innerpagebanner',
		'class' => '',
		'std'	=> get_template_directory_uri()."/images/inner-banner.jpg",
		'type' => 'upload');
		
		
	$options[] = array(
		'name' => __('Custom Slider Shortcode Area For Home Page', 'decorator'),
		'desc' => __('Enter here your slider shortcode without php tag', 'decorator'),
		'id' => 'customslider',
		'std' => '',
		'type' => 'textarea');		
		
	$options[] = array(
		'name' => __('Slider Effects and Timing', 'decorator'),
		'desc' => __('Select slider effect.','decorator'),
		'id' => 'slideefect',
		'std' => 'random',
		'type' => 'select',
		'options' => array('random'=>'Random', 'fade'=>'Fade', 'fold'=>'Fold', 'sliceDown'=>'Slide Down', 'sliceDownLeft'=>'Slide Down Left', 'sliceUp'=>'Slice Up', 'sliceUpLeft'=>'Slice Up Left', 'sliceUpDown'=>'Slice Up Down', 'sliceUpDownLeft'=>'Slice Up Down Left', 'slideInRight'=>'SlideIn Right', 'slideInLeft'=>'SlideIn Left', 'boxRandom'=>'Box Random', 'boxRain'=>'Box Rain', 'boxRainReverse'=>'Box Rain Reverse', 'boxRainGrow'=>'Box Rain Grow', 'boxRainGrowReverse'=>'Box Rain Grow Reverse' ));
		
	$options[] = array(
		'desc' => __('Animation speed should be multiple of 100.', 'decorator'),
		'id' => 'slideanim',
		'std' => 500,
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Add slide pause time.', 'decorator'),
		'id' => 'slidepause',
		'std' => 4000,
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slide Controllers', 'decorator'),
		'desc' => __('Hide/Show Direction Naviagtion of slider.','decorator'),
		'id' => 'slidenav',
		'std' => 'true',
		'type' => 'select',
		'options' => array('true'=>'Show', 'false'=>'Hide'));
		
	$options[] = array(
		'desc' => __('Hide/Show pager of slider.','decorator'),
		'id' => 'slidepage',
		'std' => 'false',
		'type' => 'select',
		'options' => array('true'=>'Show', 'false'=>'Hide'));
		
	$options[] = array(
		'desc' => __('Pause Slide on Hover.','decorator'),
		'id' => 'slidepausehover',
		'std' => 'false',
		'type' => 'select',
		'options' => array('true'=>'Yes', 'false'=>'No'));
		
	$options[] = array(
		'name' => __('Slider Image 1', 'decorator'),
		'desc' => __('First Slide', 'decorator'),
		'id' => 'slide1',
		'class' => '',
		'std' => get_template_directory_uri()."/images/slides/slider1.jpg",
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 1', 'decorator'),
		'id' => 'slidetitlesm1',
		'std' => 'We Provide',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 1', 'decorator'),
		'id' => 'slidetitle1',
		'std' => 'The Best Ideas For You',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc1',
		'std' => 'Lorem ipsum dolor sit amet. conteture gravida ipsum dolor.',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton1',
		'std' => 'Enroll Now',
		'type' => 'text');	

	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl1',
		'std' => '#',
		'type' => 'text');		
		
	
	$options[] = array(
		'name' => __('Slider Image 2', 'decorator'),
		'desc' => __('Second Slide', 'decorator'),
		'class' => '',
		'id' => 'slide2',
		'std' => get_template_directory_uri()."/images/slides/slider2.jpg",
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 2', 'decorator'),
		'id' => 'slidetitlesm2',
		'std' => 'Dream. Create. Live.',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 2', 'decorator'),
		'id' => 'slidetitle2',
		'std' => 'Innovative Ideas, Stylish Designs',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc2',
		'std' => 'Lorem ipsum dolor sit amet. conteture gravida ipsum dolor.',
		'type' => 'textarea');	
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton2',
		'std' => 'Enroll Now',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl2',
		'std' => '#',
		'type' => 'text');	
	
	$options[] = array(
		'name' => __('Slider Image 3', 'decorator'),
		'desc' => __('Third Slide', 'decorator'),
		'id' => 'slide3',
		'class' => '',
		'std' => get_template_directory_uri()."/images/slides/slider3.jpg",
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 3', 'decorator'),
		'id' => 'slidetitlesm3',
		'std' => 'Anything But Ordinary',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 3', 'decorator'),
		'id' => 'slidetitle3',
		'std' => '24/7 Support Decorator',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc3',
		'std' => 'Lorem ipsum dolor sit amet. conteture gravida ipsum dolor.',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton3',
		'std' => 'Enroll Now',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl3',
		'std' => '#',
		'type' => 'text');	
	
	$options[] = array(
		'name' => __('Slider Image 4', 'decorator'),
		'desc' => __('Third Slide', 'decorator'),
		'id' => 'slide4',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 4', 'decorator'),
		'id' => 'slidetitlesm4',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 4', 'decorator'),
		'id' => 'slidetitle4',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc4',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton4',
		'std' => '',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl4',
		'std' => '',
		'type' => 'text');				
	
	$options[] = array(
		'name' => __('Slider Image 5', 'decorator'),
		'desc' => __('Fifth Slide', 'decorator'),
		'id' => 'slide5',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 5', 'decorator'),
		'id' => 'slidetitlesm5',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 5', 'decorator'),
		'id' => 'slidetitle5',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc5',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton5',
		'std' => '',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl5',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 6', 'decorator'),
		'desc' => __('Sixth Slide', 'decorator'),
		'id' => 'slide6',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 6', 'decorator'),
		'id' => 'slidetitlesm6',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 6', 'decorator'),
		'id' => 'slidetitle6',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc6',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton6',
		'std' => '',
		'type' => 'text');		
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl6',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 7', 'decorator'),
		'desc' => __('Seventh Slide', 'decorator'),
		'id' => 'slide7',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 7', 'decorator'),
		'id' => 'slidetitlesm7',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 7', 'decorator'),
		'id' => 'slidetitle7',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc7',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton7',
		'std' => '',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl7',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 8', 'decorator'),
		'desc' => __('Eighth Slide', 'decorator'),
		'id' => 'slide8',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 8', 'decorator'),
		'id' => 'slidetitlesm8',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 8', 'decorator'),
		'id' => 'slidetitle8',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc8',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton8',
		'std' => '',
		'type' => 'text');		
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl8',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 9', 'decorator'),
		'desc' => __('Ninth Slide', 'decorator'),
		'id' => 'slide9',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 9', 'decorator'),
		'id' => 'slidetitlesm9',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 9', 'decorator'),
		'id' => 'slidetitle9',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc9',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton9',
		'std' => '',
		'type' => 'text');			
		
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl9',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Slider Image 10', 'decorator'),
		'desc' => __('Tenth Slide', 'decorator'),
		'id' => 'slide10',
		'class' => '',
		'std' => '',
		'type' => 'upload');
		
	$options[] = array(
		'desc' => __('Title Small 10', 'decorator'),
		'id' => 'slidetitlesm10',
		'std' => '',
		'type' => 'text');
		
	$options[] = array(
		'desc' => __('Title 10', 'decorator'),
		'id' => 'slidetitle10',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Description or Tagline', 'decorator'),
		'id' => 'slidedesc10',
		'std' => '',
		'type' => 'textarea');
		
	$options[] = array(
		'desc' => __('Read More Button Text', 'decorator'),
		'id' => 'slidebutton10',
		'std' => '',
		'type' => 'text');			
	
	$options[] = array(
		'desc' => __('Slide Url for Read More Button', 'decorator'),
		'id' => 'slideurl10',
		'std' => '',
		'type' => 'text');
	

	//Footer SETTINGS
	$options[] = array(
		'name' => __('Footer', 'decorator'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('Footer About Us', 'decorator'),
		'desc' => __('abput us text title for footer', 'decorator'),
		'id' => 'abouttitle',
		'std' => 'About Us',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('About Us Description', 'decorator'),
		'desc' => __('abput us text description for footer', 'decorator'),
		'id' => 'aboutusdescription',
		'std' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor quam ut mi consectetur, sed pretium quam tempor. Nunc accumsan tempor lectus, et venenatis metus volutpat vel. Pellentesque dapibus justo quam, et iaculis purus sodales vitae.<br><br>Nulla blandit velit eget enim placerat, in dignissim velit accumsan. Donec cursus bibendum nunc eu viverra. Vestium eleifend urna nec lorem tempus, in auctor dolor eleifend. Vestibulum..</p>',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Latest Posts Title', 'decorator'),
		'desc' => __('Footer latest posts title.', 'decorator'),
		'id' => 'letestpoststitle',
		'std' => 'Latest Posts',
		'type' => 'text');	
		
	$options[] = array(
		'name' => __('Footer Contact Us and Contact Us Page', 'decorator'),
		'desc' => __('Add footer contact us title here', 'decorator'),
		'id' => 'recenttitle',
		'std' => 'Recent Work',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Contact Us Page title', 'decorator'),
		'desc' => __('Add contact us page title here', 'decorator'),
		'id' => 'contacttitle',
		'std' => 'Contact Us',
		'type' => 'text');
		
	$options[] = array(	
		'desc' => __('Add company address here.', 'decorator'),
		'id' => 'address',
		'std' => '69 Market Street, Hampshire, UK',
		'type' => 'textarea');
		
	$options[] = array(		
		'desc' => __('Add phone number here.', 'decorator'),
		'id' => 'phone',
		'std' => '+01 23 456 7890 / +01 23 456 7890',
		'type' => 'text');		
		
	$options[] = array(
		'desc' => __('Add email address here.', 'decorator'),
		'id' => 'email',
		'std' => 'support@sitename.net',
		'type' => 'text');
		
	$options[] = array(		
		'desc' => __('Add fax number here.', 'decorator'),
		'id' => 'fax',
		'std' => '+01 23 456 7890',
		'type' => 'text');
		
	$options[] = array(
		'name' => __('Google Map', 'decorator'),
		'desc' => __('Use iframe code url here. DO NOT APPLY IFRAME TAG', 'decorator'),
		'id' => 'googlemap',
		'std' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d336003.6066860609!2d2.349634820486094!3d48.8576730786213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e1f06e2b70f%3A0x040b82c3688c9460!2sParis%2C+France!5e0!3m2!1sen!2sin!4v1433482358672',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Footer Social Icons', 'decorator'),
		'desc' => __('social icons for footer', 'decorator'),
		'id' => 'footersocialicon',
		'std' => '[social_area]
			[social icon="facebook" link="#"]
			[social icon="twitter" link="#"]
			[social icon="linkedin" link="#"]
			[social icon="google-plus" link="#"]
			[social icon="youtube" link="#"]
			[social icon="skype" link="#"]			
		[/social_area]
		',
		'type' => 'textarea');	
		
	$options[] = array(
		'name' => __('Footer Copyright', 'decorator'),
		'desc' => __('Copyright Text for your site.', 'decorator'),
		'id' => 'copytext',
		'std' => '&copy; Copyright Decorator 2017. All rights reserved.',
		'type' => 'textarea');
		
	$options[] = array(
		'name' => __('Footer Design by', 'decorator'),
		'desc' => __('Design by Text for your site.', 'decorator'),
		'id' => 'designbytext',
		'std' => 'Design by <a href="'.esc_url('http://www.flythemes.net/').'" target="_blank">Fly Themes</a>',
		'type' => 'textarea');	
		
	$options[] = array(
		'desc' => __('Footer Back to Top Button', 'decorator'),
		'id' => 'backtotop',
		'std' => '[back-to-top]',
		'type' => 'textarea',);

	//Short codes
	$options[] = array(
		'name' => __('Short Codes', 'decorator'),
		'type' => 'heading');
		
	$options[] = array(
		'name' => __('Photo Gallery', 'decorator'),
		'desc' => __('[photogallery filter="true" show="8"]', 'decorator'),
		'type' => 'info');	
		
	$options[] = array(
		'name' => __('Testimonials Rotator', 'decorator'),
		'desc' => __('[testimonials]', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('All Testimonials Listing', 'decorator'),
		'desc' => __('[testimonials-listing show="10"]', 'decorator'),
		'type' => 'info');	
		
	$options[] = array(
		'name' => __('Sidebar Testimonials Rotator', 'decorator'),
		'desc' => __('[sidebar-testimonials]', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Why Us', 'decorator'),
		'desc' => __('[whyus image="Add image here" title="Add title here" link="Add link here" last="Remove margin for last box type yes"] 
		Content goes here.... 		
		[/whyus]', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Recent Work', 'decorator'),
		'desc' => __('[recentwork show="3"]', 'decorator'),
		'type' => 'info');		
		
	$options[] = array(
		'name' => __('Contact Form', 'decorator'),
		'desc' => __('[contactform to_email="test@example.com" title="Contact Form"] 
', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Portfolio', 'decorator'),
		'desc' => __('[photogallery filter="true" show="12"]', 'decorator'),
		'type' => 'info');	
		
	$options[] = array(
		'name' => __('Latest News', 'decorator'),
		'desc' => __('[latest-news showposts="4" comment="show" date="show" author="show"]', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Our Skills', 'decorator'),
		'desc' => __('[skill title="Coding" percent="90" bgcolor="#65676a"][skill title="Design" percent="70" bgcolor="#65676a"][skill title="Building" percent="55" bgcolor="#65676a"][skill title="SEO" percent="100" bgcolor="#65676a"]', 'decorator'),
		'type' => 'info');	
		
	$options[] = array(
		'name' => __('Custom Button', 'decorator'),
		'desc' => __('[button align="center" name="View Gallery" link="#" arrowname="fa-chevron-right"]', 'decorator'),
		'type' => 'info');			
			
		
	$options[] = array(
		'name' => __('Search Form', 'decorator'),
		'desc' => __('[searchform]', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Social Icons ( Note: More social icons can be found at: http://fortawesome.github.io/Font-Awesome/icons/)', 'decorator'),
		'desc' => __('[social_area]<br />
			[social icon="facebook" link="#"]<br />
			[social icon="twitter" link="#"]<br />
			[social icon="linkedin" link="#"]<br />
			[social icon="google-plus" link="#"]<br />
		[/social_area]', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('2 Column Content', 'decorator'),
		'desc' => __('<pre>
[column_content type="one_half"]
	Column 1 Content goes here...
[/column_content]

[column_content type="one_half_last"]
	Column 2 Content goes here...
[/column_content]
</pre>', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('3 Column Content', 'decorator'),
		'desc' => __('<pre>
[column_content type="one_third"]
	Column 1 Content goes here...
[/column_content]

[column_content type="one_third"]
	Column 2 Content goes here...
[/column_content]

[column_content type="one_third_last"]
	Column 3 Content goes here...
[/column_content]
</pre>', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('4 Column Content', 'decorator'),
		'desc' => __('<pre>
[column_content type="one_fourth"]
	Column 1 Content goes here...
[/column_content]

[column_content type="one_fourth"]
	Column 2 Content goes here...
[/column_content]

[column_content type="one_fourth"]
	Column 3 Content goes here...
[/column_content]

[column_content type="one_fourth_last"]
	Column 4 Content goes here...
[/column_content]
</pre>', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('5 Column Content', 'decorator'),
		'desc' => __('<pre>
[column_content type="one_fifth"]
	Column 1 Content goes here...
[/column_content]

[column_content type="one_fifth"]
	Column 2 Content goes here...
[/column_content]

[column_content type="one_fifth"]
	Column 3 Content goes here...
[/column_content]

[column_content type="one_fifth"]
	Column 4 Content goes here...
[/column_content]

[column_content type="one_fifth_last"]
	Column 5 Content goes here...
[/column_content]
</pre>', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('Tabs', 'decorator'),
		'desc' => __('<pre>
[tabs]
	[tab title="TAB TITLE 1"]
		TAB CONTENT 1
	[/tab]
	[tab title="TAB TITLE 2"]
		TAB CONTENT 2
	[/tab]
	[tab title="TAB TITLE 3"]
		TAB CONTENT 3
	[/tab]
[/tabs]
</pre>', 'decorator'),
		'type' => 'info');


	$options[] = array(
		'name' => __('Toggle Content', 'decorator'),
		'desc' => __('<pre>
[toggle_content title="Toggle Title 1"]
	Toggle content 1...
[/toggle_content]
[toggle_content title="Toggle Title 2"]
	Toggle content 2...
[/toggle_content]
[toggle_content title="Toggle Title 3"]
	Toggle content 3...
[/toggle_content]
</pre>', 'decorator'),
		'type' => 'info');


	$options[] = array(
		'name' => __('Accordion Content', 'decorator'),
		'desc' => __('<pre>
[accordion]
	[accordion_content title="ACCORDION TITLE 1"]
		ACCORDION CONTENT 1
	[/accordion_content]
	[accordion_content title="ACCORDION TITLE 2"]
		ACCORDION CONTENT 2
	[/accordion_content]
	[accordion_content title="ACCORDION TITLE 3"]
		ACCORDION CONTENT 3
	[/accordion_content]
[/accordion]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Clear', 'decorator'),
		'desc' => __('<pre>
[clear]
</pre>', 'decorator'),
		'type' => 'info');	

	$options[] = array(
		'name' => __('HR / Horizontal separation line', 'decorator'),
		'desc' => __('<pre>
[hr] or &lt;hr&gt;
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Gradient Button - Small', 'decorator'),
		'desc' => __('<pre>
[gradient_button size="small" bg_color="#e00" color="#fff" text="Medium Gradient Button" title="Medium Gradient Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Gradient Button - Medium', 'decorator'),
		'desc' => __('<pre>
[gradient_button size="medium" bg_color="#060" color="#fff" text="Medium Gradient Button" title="Medium Gradient Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Gradient Button - Large', 'decorator'),
		'desc' => __('<pre>
[gradient_button size="large" bg_color="#026" color="#fff" text="Large Gradient Button" title="Large Gradient Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Gradient Button - Xtra Large', 'decorator'),
		'desc' => __('<pre>
[gradient_button size="x-large" bg_color="#00ccff" color="#fff" text="Extra Large Simple Button" title="Extra Large Simple Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Simple Button - Small', 'decorator'),
		'desc' => __('<pre>
[simple_button size="small" bg_color="#c00" color="#fff" text="Small Simple Button" title="Small Simple Button" url="#" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Simple Button - Medium', 'decorator'),
		'desc' => __('<pre>
[simple_button size="medium" bg_color="#060" color="#fff" text="Medium Simple Button" title="Medium Simple Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Simple Button - Large', 'decorator'),
		'desc' => __('<pre>
[simple_button size="large" bg_color="#026" color="#fff" text="Large Simple Button" title="Large Simple Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Simple Button - Xtra Large', 'decorator'),
		'desc' => __('<pre>
[simple_button size="x-large" bg_color="#00ccff" color="#fff" text="Extra Large Simple Button" title="Extra Large Simple Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Round Button - Light', 'decorator'),
		'desc' => __('<pre>
[round_button style="light" text="Round Button" title="Round Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Round Button - Dark', 'decorator'),
		'desc' => __('<pre>
[round_button style="dark" text="Round Button" title="Round Button" url="" position="left"]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('Message Box - Success', 'decorator'),
		'desc' => __('<pre>
[message type="success"]This is a sample of the \'success\' style message box shortcode. To use this style use the following shortcode[/message]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Message Box - Error', 'decorator'),
		'desc' => __('<pre>
[message type="error"]This is a sample of the \'error\' style message box shortcode. To use this style use the following shortcode.[/message]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Message Box - Warning', 'decorator'),
		'desc' => __('<pre>
[message type="warning"]This is a sample of the \'warning\' style message box shortcode. To use this style use the following shortcode.[/message]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Message Box - Info', 'decorator'),
		'desc' => __('<pre>
[message type="info"]This is a sample of the \'info\' style message box shortcode. To use this style use the following shortcode.[/message]
</pre>', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Message Box - About', 'decorator'),
		'desc' => __('<pre>
[message type="about"]This is a sample of the \'about\' style message box shortcode. To use this style use the following shortcode.[/message]
</pre>', 'decorator'),
		'type' => 'info');

	$options[] = array(
		'name' => __('List Styles', 'decorator'),
		'desc' => __('<pre>
[unordered_list style="list-1"]&lt;li&gt;List style 1&lt;/li&gt;[/unordered_list]
</pre>
<br />You can use above shortcode OR simply add class to ul. You can choose from list-1 to list-10 styles.<br />
<pre>
&lt;ul class="list-1"&gt;&lt;li&gt;List style 1&lt;/li&gt;&lt;/ul&gt;
</pre>
', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Pullquote', 'decorator'),
		'desc' => __('[pullquote align="left/right"]
		Your quote text...
		[/pullquote] 
', 'decorator'),
		'type' => 'info');
		
	$options[] = array(
		'name' => __('Dropcap', 'decorator'),
		'desc' => __('[dropcap]L[/dropcap] 
', 'decorator'),
		'type' => 'info');
	
	$options[] = array(
		'name' => __('Scroll to Top', 'decorator'),
		'desc' => __('[back-to-top] 
', 'decorator'),
		'type' => 'info');

	return $options;
}