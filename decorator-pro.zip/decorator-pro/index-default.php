<style>body{font-family:'Montserrat'; background-color:#ffffff;}body, .contact-form-section .address{color:#362b21;}body{font-size:13px}.logo h1 {font-family:'Montserrat';color:#ffae00;font-size:30px}.tagline{color:#ffffff;}.logo img{height:54px;}.sitenav ul li:hover > ul{background-color:#ffffff;}.sitenav ul{font-family:'Montserrat';font-size:15px; font-weight:bold;}.sitenav ul li a{color:#e0dfdf;}.sitenav ul li a:hover, .sitenav ul li.current_page_item a, .sitenav ul li.current_page_item ul li a:hover, .sitenav ul li.current-menu-ancestor a.parent{ color:#e0dfdf;}h2.section_title{ font-size:31px; color:#362b21;}a, .slide_toggle a, .postby a, .news-box .PostMeta a, .news-box .PostMeta span, .post-title a{color:#362b21;}a:hover, .slide_toggle a:hover, .news-box h6 a:hover, .postby a:hover, .news-box .PostMeta a:hover{color:#ffae00;}.news-box .PostMeta{color:#9d9d9d; font-weight:bold;}.cols-3 h5{color:#ffffff; font-size:20px; font-weight:bold; border-color:#474747;}.copyright-txt{color:#ffffff}.header{background-color:rgba(0, 0, 0, 0.3); color:#ffffff;}.social-icons a{ color:#e0ccba; border-color:#453d2d;}.social-icons a:hover{ color:#e0ccba; background-color:#ffae00;}#commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit{background-color:#ffae00; color:#ffffff; }#commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, p.read-more a:hover, .pagination ul li .current, .pagination ul li a:hover,.headertop .right a:hover, .wpcf7 form input[type='submit']:hover{background-color:#424242; color:#ffffff;}.button{border:1px solid #42433d; color:#33281e ;}.button:hover{ background-color:#ffae00; color:#ffffff; border:1px solid #ffae00;}a.morebutton{background-color:#ffae00; color:#392e24 ; }a.morebutton:hover{background-color:#392e24; color:#fff;}a.buttonstyle1{border-color:#42433d color:#33281e; }a.buttonstyle1:hover{border-color:#ffae00; background-color:#ffae00; color:#33281e;}aside.widget, #sidebar .search-form input.search-field, .contact_right #testimonials{ background-color:#151515; color:#e4e3e3;  }.getquote h2{color:#ffffff;}h3.widget-title{ background-color:#242424; color:#e4e3e3;}#footer-wrapper{background-color:#33281e; color:#b38f6e;}.contactdetail a:hover, .cols-3 h5 span, .cols-3 ul li a:hover, .cols-3 ul li.current_page_item a{color:#ffae00; }.contactdetail a{color:#c1c0c0; }.copyright-wrapper{background-color:#251d15;}.nivo-controlNav a{background-color:#ffffff}.nivo-controlNav a.active{background-color:#ffae00}.nivo-controlNav a{border-color:#ffffff}#sidebar ul li{border-color:#424242}#sidebar ul li a{color:#e4e3e3; }#sidebar ul li a:hover{color:#e4e3e3; }.nivo-caption h6{ font-family:'Montserrat'; color:#ffffff; font-size:16px;}.nivo-caption h2{ font-family:'Montserrat'; color:#ffffff; font-size:43px;}.nivo-caption p{font-family:'Montserrat'; color:#ffffff; font-size:16px;}.copyright-wrapper a{ color: #ffae00; }.copyright-wrapper a:hover{ color:#ffae00; }.toggle a{ background-color:#000000; color:#e4e3e3; }h1,h2,h3,h4,h5,h6{ font-family:'Montserrat'; }h1{ font-size:35px; color:#362b21;}h2{ font-size:25px; color:#362b21;}h3{ font-size:20px; color:#33281e;}h4{ font-size:18px; color:#33281e;}h5{font-size:16px; color:#33281e;}h6{ font-size:14px; color:#e4e3e3;}.header-top{ background-color:#362b21; color:#e0ccba;}.header-top .left .fa{ color:#ffffff;}.header-top .left a{ color:#969bae;}.cols-3 .social-icons a{ background-color:#574535; color:#ffffff;}.cols-3 .social-icons a:hover{ color:#ffffff; background-color:#ffae00;}.nivo-directionNav a{background-color:rgba(0,0,0,0.7);}.news-box h6 a{ color:#362b21; }.fourbox{ background-color:#ffffff; color:#fdf5ec; }.fourbox h3{ color:#ffffff; }.tabs-wrapper ul.tabs li a{ background-color:#151515; color:#e4e3e3; }.tabs-wrapper ul.tabs li a.selected{ background-color:#242424; color:#e4e3e3; }.tabs-wrapper .tab-content{ border-color:#424242; color:#e4e3e3; }.accordion-box h2{ border-color:#424242; color:#e4e3e3; }.accordion-box h2.active{ background-color:#242424; color:#e4e3e3; }.acc-content{ background-color:#151515; color:#e4e3e3; }.titledesbox h3, .titledesbox h3 a{color:#e4e3e3;}.owl-controls .owl-dot{ background-color:#33281e; }.owl-controls .owl-dot.active{ background-color:#ffae00; }#clienttestiminials h6 a{ color:#ffae00; }#clienttestiminials span{ color:#33281e;}#clienttestiminials p{color:#33281e;}.skill-bg{ background-color:#33281e; }.skillbar-bar{ background-color:#ffae00 !important; }ul.recent-post li a{ color:#b38f6e;}</style>

<body id="top" class="home blog logged-in">
		<div id="pagewrap" >
				<div class="header-top">
					<div class="container">
						<div class="left">
							<i class="fa fa-phone"></i> +11 123 456 7890 <span class="phno"><a href="mailto:info@sitename.com"><i class="fa fa-envelope"></i>info@sitename.com</a></span>
						</div>    
						
						<div class="right">
							<div class="social-icons">
                            	<a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                            </div>
						</div>
						<div class="clear"></div>
					</div>
				</div><!--end header-top-->

				<div class="header">
					<div class="container">
						<div class="logo">
							<a href="<?php echo home_url(); ?>">
								<h1>Decorator Pro</h1>                                
							</a>
                            <p>Professional Wrodpress Theme</p>
						</div><!-- .logo -->                 
						<div class="header_right">  
							<div class="toggle">
								<a class="toggleMenu" href="#">Menu</a>
							</div><!-- toggle -->
                            <div class="sitenav">                   
								<ul>
									<li class="current_page_item"><a href="<?php echo home_url(); ?>">Home</a></li>
									<li><a href="#">Sample Page</a></li>
								</ul>
								<div class="clear"></div>
							</div><!-- sitenav --> 
						</div><!--header_right-->                       
						<div class="clear"></div>
					</div><!-- .container-->
				</div><!-- .header -->
				
				
				<div class="slider-main">
					<div id="slider" class="nivoSlider">
						<img src="<?php echo get_template_directory_uri(); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1"/>
					</div> 
					<div id="slidecaption1" class="nivo-html-caption">                    	
						<h6>We Provide</h6>
                        <a href="#"><h2>The Best Ideas For You</h2></a>						
						<p>Lorem ipsum dolor sit amet. conteture gravida ipsum dolor.</p>						
					</div>                 
				</div><!-- slider -->



				<section id="pagearea">
					<div class="container">
						<div class="pagearea-inner">
						
							<div class="fourbox" style="background-color:#362b21;">
								<div class="thumbbx">
									<img src="<?php echo get_template_directory_uri(); ?>/images/feature1.jpg" alt="" />
								</div>
								<div class="fourbxcontent">
									<a href="#"><h3>Bedroom Designs</h3></a>
									<p>Proin et augue nisl. Phasellus sed pharetra lorem, sed cursus libero. Maecenas sit amet dapibus turpis. Etiam fermentum pharetra nisl</p> 									
								</div>                    
							</div>
							
							<div class="fourbox" style="background-color:#362b21;">
								<div class="thumbbx">
									<img src="<?php echo get_template_directory_uri(); ?>/images/feature2.jpg" alt="" />
								</div>
								<div class="fourbxcontent">
									<a href="#"><h3>Kitchen Designs</h3></a>
									<p>Proin et augue nisl. Phasellus sed pharetra lorem, sed cursus libero. Maecenas sit amet dapibus turpis. Etiam fermentum pharetra nisl</p> 									
								</div>                    
							</div>
							
							<div class="fourbox last_column" style="background-color:#362b21;">
								<div class="thumbbx">
									<img src="<?php echo get_template_directory_uri(); ?>/images/feature3.jpg" alt="" />
								</div>
								<div class="fourbxcontent">
									<a href="#"><h3>Living Room Designs</h3></a>
									<p>Proin et augue nisl. Phasellus sed pharetra lorem, sed cursus libero. Maecenas sit amet dapibus turpis. Etiam fermentum pharetra nisl</p> 									
								</div>                    
							</div>					
							<div class="clear"></div>
						</div><!-- .pagearea-inner -->
					</div><!--container-->
				</section><!-- #pagearea -->


	            <section class="menu_page" style="background-color:#f6f6f5;">
					<div class="container">
						<div class="two-column">
                        	<h2>About Us</h2>
							 <div class="column-thumb">
                             	<img src="<?php echo get_template_directory_uri(); ?>/images/twocol-img.jpg">
                             </div>
                             <div class="column-content">
                             	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam non vulputate risus, nec dignissim ex. Mauris feugiat nisl ex. Vivamus ornare, diam a efficitur dignissim, enim arcu faucibus ipsum, eget convallis lorem sem id neque. In eu condimentum dolor. Duis ultrices dolor sit amet nibh semper gravida. Aliquam sem velit, mattis eu venenatis non, pellentesque ac velit. Mauris placerat nisi vitae nunc condimentum, id pretium nisi faucibus. Curabitur sed risus ante. Vestibulum nec imperdiet eros, vitae mattis velit.</p>
                                <p></p>Nulla consectetur laoreet purus, nec condimentum nisl consequat quis. Donec varius convallis mi, at condimentum dolor convallis sit amet. Aliquam porta nisi sed dictum posuere. In imperdiet eros et justo viverra elementum. Aenean vitae convallis enim. Morbi interdum accumsan ex vitae rutrum. Nunc accumsan justo eget ante sodales cursus. Phasellus finibus metus non metus lobortis rhoncus. Vestibulum sit amet pellentesque ipsum.
                             <div class="clear"></div>
                             <a class="buttonstyle1" href="#">Read More</a>
                             </div>
							<div class="clear"></div>
						 </div><!-- two-column -->  
						 <div class="clear"></div>                 
					 </div><!-- container -->
				</section>
                
                <section class="menu_page">
					<div class="container">
						<div class="recent-work">
                        	<h2>Recent Work</h2>
                            <div class="recent-box">
								<div class="recent-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/project1.jpg">
									<div class="recent-desc">
										<h3>Project 1</h3>
										<p>Lorem ipsum dolor sit amet, consectetur ipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignisim nulla. Ut vestibulum mi nec arcu porta, veldo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst. Nulla euiod tempor rutrum. Curabitur pretium id urna quis ultricies. Sed pharetra lacinia eros sed varius. Morbi hendrerit…</p>	
										<a href="#" class="view">View Product Details</a>
									</div>
                                </div>			 
							</div>
                            
                            <div class="recent-box">
								<div class="recent-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/project2.jpg">
									<div class="recent-desc">
										<h3>Project 2</h3>
										<p>Lorem ipsum dolor sit amet, consectetur ipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignisim nulla. Ut vestibulum mi nec arcu porta, veldo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst. Nulla euiod tempor rutrum. Curabitur pretium id urna quis ultricies. Sed pharetra lacinia eros sed varius. Morbi hendrerit…</p>	
										<a href="#" class="view">View Product Details</a>
									</div>
                                </div>			 
							</div>
                            
                            <div class="recent-box last">
								<div class="recent-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/project3.jpg">
									<div class="recent-desc">
										<h3>Project 3</h3>
										<p>Lorem ipsum dolor sit amet, consectetur ipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignisim nulla. Ut vestibulum mi nec arcu porta, veldo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst. Nulla euiod tempor rutrum. Curabitur pretium id urna quis ultricies. Sed pharetra lacinia eros sed varius. Morbi hendrerit…</p>	
										<a href="#" class="view">View Product Details</a>
									</div>
                                </div>			 
							</div><div class="clear"></div>
                            
                            
                        </div><!-- recent-work -->	                 
				 	</div><!-- container -->
				</section>           
            
				<section class="menu_page" style="background-color:#f6f6f5;">
					<div class="container">
						<div class="whyus">
                        							
                        	<div class="whyus-box">
								<div class="whyus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/whyus.png"></div>
								<div class="whyus-desc">
									<h2>Why Us</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.</p>
									<a href="#" class="button">Read More &gt;</a>
								</div>						
							</div> 
                            
                            <div class="whyus-box">
								<div class="whyus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/mission.png"></div>
								<div class="whyus-desc">
									<h2>Mission</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.</p>
									<a href="#" class="button">Read More &gt;</a>
								</div>						
							</div> 
                            
                            <div class="whyus-box" id="last">
								<div class="whyus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/values.png"></div>
								<div class="whyus-desc">
									<h2>Our Values</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.</p>
									<a href="#" class="button">Read More &gt;</a>
								</div>						
							</div><div class="clear"></div> 
                                  								
						</div><!-- whyus --> 					                 
					</div><!-- container -->
				</section>
                
                <section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/quote.jpg); background-repeat:no-repeat; background-position: center top; background-attachment:fixed; background-size:cover; " id="testimonialswrap" class="menu_page">
					<div class="container">
						<div class="getquote">
							<h2 class="section_title">You Don't Need A Contractor To Make Over Your Walls</h2>
							<p>Aliquam finibus felis eget ipsum finibus, ut pulvinar sem interdum. Suspendisse vitae ex tempus, lobortis leo a, rutrum ligula. Integer ut ligula pretium, faucibus arcu non, dignissim ex. Sed facilisis sem urna</p>
                            <div class="clear"></div><a href="#" class="morebutton">Get A Quote Now</a>
						</div><!-- quote -->  
						<div class="clear"></div>                 
					</div><!-- container -->
				</section>
                
                
                <section class="menu_page" style="background-color:#f6f6f5;">
					<div class="container">
						<div class="">
							<h2 class="section_title">Latest From The Blog</h2>
								<div class="fourcolumn-news">
									<div class="news-box">
										<div class="news-thumb">
											<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/blog1.jpg" alt=" " /></a>             										
										</div>
										<div class="newsdesc">
											<h6><a href="#">Sed vestibulum dolor sit amet scelerisque</a></h6>
                                            <div class="PostMeta">										
												<i class="fa fa-user"></i> Posted By <a href="#">Admin</a> <i class="fa fa-clock-o"></i> On <span>9 January 2017</span>									
											</div>
                                            <p>Sed vestibulum dolor sit amet scelerisque convallis. Proin facilisis vitae est quis varius. Vestibulum at odio dui. Nam in consectetur justo. In ac augue sit amet lectus…</p>
                                           <a href="#" class="buttonstyle1">Read More</a>													 
										</div>
										<div class="clear"></div>
									 </div>
									
									<div class="news-box">
										<div class="news-thumb">
											<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/blog2.jpg" alt=" " /></a>             										
										</div>
										<div class="newsdesc">
											<h6><a href="#">Aliquam volutpat neque sed ipsum congue</a></h6>
                                            <div class="PostMeta">										
												<i class="fa fa-user"></i> Posted By <a href="#">Admin</a> <i class="fa fa-clock-o"></i> On <span>9 January 2017</span>									
											</div>
                                            <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc quis nunc et magna suscipit gravida. Morbi posuere rutrum lacus eget malesuada. Mauris mattis,…</p>
                                           <a href="#" class="buttonstyle1">Read More</a>													 
										</div>
										<div class="clear"></div>
									 </div>
									
									<div class="news-box last">
										<div class="news-thumb">
											<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/blog3.jpg" alt=" " /></a>             										
										</div>
										<div class="newsdesc">
											<h6><a href="#">Nam sed leo sit amet ligula gravida maximus</a></h6>
                                            <div class="PostMeta">										
												<i class="fa fa-user"></i> Posted By <a href="#">Admin</a> <i class="fa fa-clock-o"></i> On <span>9 January 2017</span>									
											</div>
                                            <p>Nulla euismod tempor rutrum. Curabitur pretium id urna quis ultricies. Sed pharetra lacinia eros sed varius. Morbi hendrerit commodo mi quis lobortis. Morbi tristique tellus sit amet</p>
                                           <a href="#" class="buttonstyle1">Read More</a>													 
										</div>
										<div class="clear"></div>
									 </div>                               
                                    
									<div class="clear"></div>
								</div>
						</div><!-- .end section class -->  
						<div class="clear"></div>                 
					</div><!-- container -->
				</section>            
            
				<section class="menu_page">
					<div class="container">
						<div class="">
							<h2 class="section_title">What Client’s Say About Us</h2>
							<div id="clienttestiminials">
								<div class="owl-carousel">
								
									<div class="item">                                  
				   						<blockquote><p>Sed suscipit mauris nec mauris vulputate, a posuere libero congue. Nam laoreet elit eu erat pulvinar, et efficitur nibh euismod. Proin venenatis orci sit amet nisl finibus vehicula. Nam metus lorem, hendrerit quis ante eget, lobortis elementum neque. Aliquam in ullamcorper quam. Integer euismod ligula in mauris vehicula imperdiet. Cras in convallis ipsum. Phasellus tortor turpis, aliquet non commodo quis, tristique tempus turpis. Cras nec erat orci.</p></blockquote>
				   						<h6><a href="#">John Doe</a></h6>
				   						<span>( Some Company Name )</span>
               						</div>
				  
									<div class="item">
                                       <blockquote><p>Sed suscipit mauris nec mauris vulputate, a posuere libero congue. Nam laoreet elit eu erat pulvinar, et efficitur nibh euismod. Proin venenatis orci sit amet nisl finibus vehicula. Nam metus lorem, hendrerit quis ante eget, lobortis elementum neque. Aliquam in ullamcorper quam. Integer euismod ligula in mauris vehicula imperdiet. Cras in convallis ipsum. Phasellus tortor turpis, aliquet non commodo quis, tristique tempus turpis. Cras nec erat orci.</p></blockquote>
                                       <h6><a href="#">Sarah Brown</a></h6>
                                       <span>( Some Company Name )</span>
                                   </div>
			  
                                    <div class="item">                                   
                                       <blockquote><p>Sed suscipit mauris nec mauris vulputate, a posuere libero congue. Nam laoreet elit eu erat pulvinar, et efficitur nibh euismod. Proin venenatis orci sit amet nisl finibus vehicula. Nam metus lorem, hendrerit quis ante eget, lobortis elementum neque. Aliquam in ullamcorper quam. Integer euismod ligula in mauris vehicula imperdiet. Cras in convallis ipsum. Phasellus tortor turpis, aliquet non commodo quis, tristique tempus turpis. Cras nec erat orci.</p></blockquote>
                                       <h6><a href="#">Julia Doe</a></h6>
                                       <span>( Some Company Name )</span>
                                   </div>
			  
                                    <div class="item">                                   
                                       <blockquote><p>Sed suscipit mauris nec mauris vulputate, a posuere libero congue. Nam laoreet elit eu erat pulvinar, et efficitur nibh euismod. Proin venenatis orci sit amet nisl finibus vehicula. Nam metus lorem, hendrerit quis ante eget, lobortis elementum neque. Aliquam in ullamcorper quam. Integer euismod ligula in mauris vehicula imperdiet. Cras in convallis ipsum. Phasellus tortor turpis, aliquet non commodo quis, tristique tempus turpis. Cras nec erat orci.</p></blockquote>
                                       <h6><a href="#">Jenifer Doe</a></h6>
                                       <span>( Some Company Name )</span>
                                   </div>
								
								</div>
							</div>
						</div><!-- .end section class -->  
						<div class="clear"></div>                 
					</div><!-- container -->
				</section>
                
                <section class="menu_page" style="background-color:#f6f6f5;">
					<div class="container">
						<div class="quote">
							<h2 class="section_title">Our Clients</h2>
							<ul id="flexiselDemo3">
                            	<li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/logo1.jpg" alt=" " /></a></li>
                                <li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/logo2.jpg" alt=" " /></a></li>
                                <li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/logo3.jpg" alt=" " /></a></li>
                                <li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/logo4.jpg" alt=" " /></a></li>
                                <li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/logo5.jpg" alt=" " /></a></li>
                            </ul>
						</div><!-- quote -->  
						<div class="clear"></div>                 
					</div><!-- container -->
				</section>
        
        
        		<div id="footer-contact">
                  	<div class="footer-inner">
                    	<div class="contact-cols">                       		
                       		<div class="foot-icon"><i class="fa fa-map-marker"></i></div><h4>69 Market Street, Hampshire, UK</h4>                       		
                    	</div><!-- contact-cols -->
                        
                        <div class="contact-cols">                           	
                           	<div class="foot-icon"><i class="fa fa-phone"></i></div><h4>+01 23 456 7890 / +01 23 456 7890</h4>                           
                        </div><!-- contact-cols -->
                        
                        <div class="contact-cols last">							  
                            <div class="foot-icon"><i class="fa fa-envelope"></i></div><h4><a href="mailto:support@sitename.net">support@sitename.net</a></h4>                        </div><!-- contact-cols -->
                   		<div class="clear"></div>
                  	</div><!-- footer-inner -->
        		</div><!-- footer-contact -->
            
				<div id="footer-wrapper">
					<div class="container">
						
						<div class="cols-3 widget-column-1"> 
							<h5>About Us</h5>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor quam ut mi consectetur, sed pretium quam tempor. Nunc accumsan tempor lectus, et venenatis metus volutpat vel. Pellentesque dapibus justo quam, et iaculis purus sodales vitae.<br><br>Nulla blandit velit eget enim placerat, in dignissim velit accumsan. Donec cursus bibendum nunc eu viverra. Vestium eleifend urna nec lorem tempus, in auctor dolor eleifend. Vestibulum..</p> 
                            <div class="social-icons">
								<a href="#" target="_blank" class="fa fa-facebook" title="facebook"></a>
								<a href="#" target="_blank" class="fa fa-twitter" title="twitter"></a>
								<a href="#" target="_blank" class="fa fa-linkedin" title="linkedin"></a>
								<a href="#" target="_blank" class="fa fa-google-plus" title="google-plus"></a>
								<a href="#" target="_blank" class="fa fa-youtube" title="youtube"></a>
								<a href="#" target="_blank" class="fa fa-skype" title="skype"></a>			
							</div>
						</div>
						   
						<div class="cols-3 widget-column-2">                           	
               				<h5>Latest Posts</h5>
                				<ul class="recent-post"> 
       								<li>
                    					<strong><a href="#">Sed vestibulum dolor sit amet scelerisque</a></strong>                   
                    					<p>Sed vestibulum dolor sit amet scelerisque convallis. Proin facilisis…</p>					
                    				</li>
                                    
                                    <li>
                    					<strong><a href="#">Aliquam volutpat neque sed ipsum congue</a></strong>                   
                    					<p>Cum sociis natoque penatibus et magnis dis parturient montes,…</p>					
                    				</li>
                                    
                                    <li>
                                        <strong><a href="#">Nam sed leo sit amet ligula gravida maximus</a></strong>                   
                                        <p>Nulla euismod tempor rutrum. Curabitur pretium id urna quis…</p>					
                    				</li>
                        		</ul>                                      
						</div>
							
				
						<div class="cols-3 widget-column-3">  
             				<h5>Recent Work</h5>
               					<ul class="foot-recent">                	                  	
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project1.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                   	<li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project2.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project3.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li><div class="clear"></div>
                                    
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project4.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project5.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project6.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li><div class="clear"></div>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project7.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project8.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                    <li>
                                        <a href="#">            
                                        <div class="footerthumb">
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/project9.jpg" alt=" " />
                                        </div>
                                        </a>                    				
                                    </li>
                                </ul>
                                	
                		 </div> 
						 <div class="clear"></div>
					</div><!--end .container-->
		 
					<div class="copyright-wrapper">
						<div class="container">
                        	<div class="copyright-inner">
                                <div class="copyright-txt">&copy; Copyright Decorator 2017. All rights reserved.</div>
                                 <div class="designby">Design by <a href="http://www.flythemes.net/" target="_blank">Fly Themes</a></div>
                                <div class="clear"></div>
                            </div><!-- copyright-inner -->
						</div> 
					</div>
		   
				</div>    
				<div id="back-top">
					<a title="Top of Page" href="#top"><span></span></a>
				</div>
		</div>
</body>
</html>