<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Decorator
 */
?>
<div id="sidebar" <?php if( is_page_template('blog-post-left-sidebar.php')){?> style="float:left;"<?php } ?>>
    
    <?php if ( ! dynamic_sidebar( 'sidebar-main' ) ) : ?>
            
            <?php echo do_shortcode('[searchform]'); ?>
       
        
     <aside id="skills" class="widget">           
            <?php echo do_shortcode('[accordion]
	[accordion_content title="Why Us"]
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.
	[/accordion_content]
	[accordion_content title="Our Mission"]
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.
	[/accordion_content]
	[accordion_content title="Our Values"]
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus et suscipit lectus. Etiam nec diam eleifend, tincidunt erat ut, dignissim nulla. Ut vestibulum mi nec arcu porta, vel commodo mi vehicula. Morbi aliquet sed nisi in viverra. In hac habitasse platea dictumst.
	[/accordion_content]
[/accordion]'); ?>
        </aside>    
               
         
        
       <h3 class="widget-title">Client Testimonials</h3>
        <aside id="testimonials-widget" class="widget">           
            <?php echo do_shortcode('[sidebar-testimonials]'); ?>
        </aside> 
    <?php endif; // end sidebar widget area ?>
	
</div><!-- sidebar -->